import React, { createContext, useContext, useState } from 'react';

const LanguageContext = createContext();

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};

const translations = {
  en: {
    // Login Page
    welcome: 'Welcome to Moushi Cookbook',
    email: 'Email',
    password: 'Password',
    login: 'Login',

    // Navigation
    home: 'Home',
    categories: 'Categories',
    products: 'Products',
    classes: 'Classes',
    search: 'Search',
    logout: 'Logout',

    // Home Page
    welcomeTitle: 'Welcome to Moushi Cookbook',
    welcomeSubtitle: 'Discover authentic Tamil recipes and cooking techniques',
    searchPlaceholder: 'Search for recipes...',
    searchButton: 'Search',

    // Categories
    favoriteRecipes: 'Favorite Recipes',
    mostPopularRecipes: 'Most Popular Recipes',
    trendingRecipes: 'Trending Recipes',
    chefSignatureRecipes: 'Chef Signature Recipes',
    easytoCook: 'Easy to Cook',
    lunchbox: 'Lunch Box Recipes',
    healthyRecipes: 'Healthy Recipes',
    breakfastRecipes: 'Breakfast Recipes',
    gymGoers: 'Gym-Goers',
    snacksRecipe: 'Snacks Recipe',
    streetFood: 'Street Food',
    baking: 'Baking',
    internationalCuisine: 'International Cuisine',

    // Recipe Details
    ingredients: 'Ingredients',
    instructions: 'Instructions',
    calories: 'Calories',
    cookingTime: 'Cooking Time',
    addToFavorites: 'Add to Favorites',

    // Products
    groceries: 'Groceries',
    kitchenGadgets: 'Kitchen Gadgets',
    addToCart: 'Add to Cart',
    addToWishlist: 'Add to Wishlist',
    price: 'Price',

    // Classes
    cookingClasses: 'Cooking Classes',
    bakingClasses: 'Baking Classes',
    beginnerLevel: 'Beginner Level',
    intermediateLevel: 'Intermediate Level',
    advancedLevel: 'Advanced Level',

    // Footer
    aboutUs: 'About Us',
    contactUs: 'Contact Us',
    privacyPolicy: 'Privacy Policy',
    termsOfService: 'Terms of Service',
    allRightsReserved: 'All rights reserved'
  },

  ta: {
    // Login Page
    welcome: 'மௌஷி சமையல் புத்தகத்திற்கு வரவேற்கிறோம்',
    email: 'மின்னஞ்சல்',
    password: 'கடவுச்சொல்',
    login: 'உள்நுழை',

    // Navigation
    home: 'முகப்பு',
    categories: 'வகைகள்',
    products: 'பொருட்கள்',
    classes: 'வகுப்புகள்',
    search: 'தேடல்',
    logout: 'வெளியேறு',

    // Home Page
    welcomeTitle: 'மௌஷி சமையல் புத்தகத்திற்கு வரவேற்கிறோம்',
    welcomeSubtitle: 'தமிழ் சமையல் முறைகளை கண்டறிந்து கற்றுக்கொள்ளுங்கள்',
    searchPlaceholder: 'சமையல் குறிப்புகளை தேடுங்கள்...',
    searchButton: 'தேடு',

    // Categories
    favoriteRecipes: 'பிடித்த சமையல் குறிப்புகள்',
    mostPopularRecipes: 'மிகவும் பிரபலமான சமையல் குறிப்புகள்',
    trendingRecipes: 'டிரெண்டிங் சமையல் குறிப்புகள்',
    chefSignatureRecipes: 'சமையல்காரர் சிறப்பு குறிப்புகள்',
    easytoCook: 'எளிதாக சமைக்க',
    lunchbox: 'லஞ்ச் பாக்ஸ் சமையல்',
    healthyRecipes: 'ஆரோக்கியமான சமையல்',
    breakfastRecipes: 'காலை உணவு சமையல்',
    gymGoers: 'ஜிம் செல்பவர்களுக்கு',
    snacksRecipe: 'தின்பண்டங்கள்',
    streetFood: 'தெரு உணவு',
    baking: 'பேக்கிங்',
    internationalCuisine: 'சர்வதேச உணவு',

    // Recipe Details
    ingredients: 'தேவையான பொருட்கள்',
    instructions: 'செய்முறை',
    calories: 'கலோரிகள்',
    cookingTime: 'சமையல் நேரம்',
    addToFavorites: 'பிடித்தவையில் சேர்',

    // Products
    groceries: 'மளிகை பொருட்கள்',
    kitchenGadgets: 'சமையலறை கருவிகள்',
    addToCart: 'கார்ட்டில் சேர்',
    addToWishlist: 'விஷ்லிஸ்ட்டில் சேர்',
    price: 'விலை',

    // Classes
    cookingClasses: 'சமையல் வகுப்புகள்',
    bakingClasses: 'பேக்கிங் வகுப்புகள்',
    beginnerLevel: 'ஆரம்ப நிலை',
    intermediateLevel: 'நடுத்தர நிலை',
    advancedLevel: 'மேம்பட்ட நிலை',

    // Footer
    aboutUs: 'எங்களை பற்றி',
    contactUs: 'தொடர்பு கொள்ள',
    privacyPolicy: 'தனியுரிமை கொள்கை',
    termsOfService: 'சேவை விதிமுறைகள்',
    allRightsReserved: 'அனைத்து உரிமைகளும் பாதுகாக்கப்பட்டவை'
  },

  hi: {
    // Login Page
    welcome: 'मौशी कुकबुक में आपका स्वागत है',
    email: 'ईमेल',
    password: 'पासवर्ड',
    login: 'लॉग इन',

    // Navigation
    home: 'होम',
    categories: 'श्रेणियां',
    products: 'उत्पाद',
    classes: 'क्लासेस',
    search: 'खोजें',
    logout: 'लॉग आउट',

    // Home Page
    welcomeTitle: 'मौशी कुकबुक में आपका स्वागत है',
    welcomeSubtitle: 'प्रामाणिक तमिल व्यंजन और खाना पकाने की तकनीकें खोजें',
    searchPlaceholder: 'व्यंजनों की खोज करें...',
    searchButton: 'खोजें',

    // Categories
    favoriteRecipes: 'पसंदीदा व्यंजन',
    mostPopularRecipes: 'सबसे लोकप्रिय व्यंजन',
    trendingRecipes: 'ट्रेंडिंग व्यंजन',
    chefSignatureRecipes: 'शेफ के विशेष व्यंजन',
    easytoCook: 'आसान व्यंजन',
    lunchbox: 'लंच बॉक्स व्यंजन',
    healthyRecipes: 'स्वस्थ व्यंजन',
    breakfastRecipes: 'नाश्ते के व्यंजन',
    gymGoers: 'जिम जाने वालों के लिए',
    snacksRecipe: 'नाश्ता व्यंजन',
    streetFood: 'स्ट्रीट फूड',
    baking: 'बेकिंग',
    internationalCuisine: 'अंतर्राष्ट्रीय व्यंजन',

    // Recipe Details
    ingredients: 'सामग्री',
    instructions: 'निर्देश',
    calories: 'कैलोरी',
    cookingTime: 'पकाने का समय',
    addToFavorites: 'पसंदीदा में जोड़ें',

    // Products
    groceries: 'किराना',
    kitchenGadgets: 'रसोई के उपकरण',
    addToCart: 'कार्ट में जोड़ें',
    addToWishlist: 'विशलिस्ट में जोड़ें',
    price: 'कीमत',

    // Classes
    cookingClasses: 'खाना पकाने की कक्षाएं',
    bakingClasses: 'बेकिंग कक्षाएं',
    beginnerLevel: 'शुरुआती स्तर',
    intermediateLevel: 'मध्यम स्तर',
    advancedLevel: 'उन्नत स्तर',

    // Footer
    aboutUs: 'हमारे बारे में',
    contactUs: 'संपर्क करें',
    privacyPolicy: 'गोपनीयता नीति',
    termsOfService: 'सेवा की शर्तें',
    allRightsReserved: 'सभी अधिकार सुरक्षित'
  }
};

export const LanguageProvider = ({ children }) => {
  const [currentLanguage, setCurrentLanguage] = useState('en');

  const t = (key) => {
    return translations[currentLanguage][key] || key;
  };

  const changeLanguage = (language) => {
    setCurrentLanguage(language);
  };

  return (
    <LanguageContext.Provider value={{ currentLanguage, changeLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};