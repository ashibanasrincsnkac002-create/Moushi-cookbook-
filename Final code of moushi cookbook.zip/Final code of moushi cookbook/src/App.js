import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import './App.css';
import LoginPage from './components/LoginPage';
import HomePage from './components/HomePage';
import CategoryPage from './components/CategoryPage';
import RecipePage from './components/RecipePage';
import ProductsPage from './components/ProductsPage';
import ClassesPage from './components/ClassesPage';
import SearchPage from './components/SearchPage';
import Header from './components/Header';
import Footer from './components/Footer';
import {LanguageProvider} from './context/LanguageContext';

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);

  useEffect(() => {
    // Check if user is logged in from localStorage
    const user = localStorage.getItem('moushiUser');
    if (user) {
      setIsLoggedIn(true);
      setCurrentUser(JSON.parse(user));
    }
  }, []);

  const handleLogin = (userData) => {
    setIsLoggedIn(true);
    setCurrentUser(userData);
    localStorage.setItem('moushiUser', JSON.stringify(userData));
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setCurrentUser(null);
    localStorage.removeItem('moushiUser');
  };

  return (
    <LanguageProvider>
      <Router>
        <div className="App">
          {isLoggedIn && <Header user={currentUser} onLogout={handleLogout} />}
          <Routes>
            <Route 
              path="/login" 
              element={
                !isLoggedIn ? 
                <LoginPage onLogin={handleLogin} /> : 
                <Navigate to="/home" />
              } 
            />
            <Route 
              path="/home" 
              element={
                isLoggedIn ? 
                <HomePage /> : 
                <Navigate to="/login" />
              } 
            />
            <Route 
              path="/category/:categoryName" 
              element={
                isLoggedIn ? 
                <CategoryPage /> : 
                <Navigate to="/login" />
              } 
            />
            <Route 
              path="/recipe/:recipeId" 
              element={
                isLoggedIn ? 
                <RecipePage /> : 
                <Navigate to="/login" />
              } 
            />
            <Route 
              path="/products" 
              element={
                isLoggedIn ? 
                <ProductsPage /> : 
                <Navigate to="/login" />
              } 
            />
            <Route 
              path="/classes" 
              element={
                isLoggedIn ? 
                <ClassesPage /> : 
                <Navigate to="/login" />
              } 
            />
            <Route 
              path="/search" 
              element={
                isLoggedIn ? 
                <SearchPage /> : 
                <Navigate to="/login" />
              }
            />
            <Route path="/" element={<Navigate to="/login" />} />
          </Routes>
          {isLoggedIn && <Footer />}
        </div>
      </Router>
    </LanguageProvider>
  );
}

export default App;