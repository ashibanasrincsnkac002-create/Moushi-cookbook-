import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';

const Header = ({ user, onLogout }) => {
  const { t, currentLanguage, changeLanguage } = useLanguage();
  const location = useLocation();

  const isActive = (path) => {
    return location.pathname === path ? 'nav-tab active' : 'nav-tab';
  };

  return (
    <>
      <header className="header">
        <div className="header-left">
           <img 
  src="/image.png" 
  alt="Moushi Cookbook Logo" 
  className="header-logo"
  style={{ width: '60px', height: '60px', margin: '0 auto 15px' }}
  onError={(e) => {
    e.target.onerror = null; // prevent infinite loop
    e.target.src = '/images/photo.png'; // fallback if missing
  }}
          />
          <h1>Moushi Cookbook</h1>
        </div>

        <div className="header-right">
          <div className="language-selector">
            <select 
              value={currentLanguage} 
              onChange={(e) => changeLanguage(e.target.value)}
            >
              <option value="en">English</option>
              <option value="ta">தமிழ்</option>
              <option value="hi">हिंदी</option>
            </select>
          </div>

          <div className="user-info">
            <span>Welcome, {user?.name || user?.email}!</span>
            <button onClick={onLogout} className="logout-btn">
              {t('logout')}
            </button>
          </div>
        </div>
      </header>

      <nav className="nav-tabs">
        <Link to="/home" className={isActive('/home')}>
          {t('home')}
        </Link>
        <Link to="/search" className={isActive('/search')}>
          {t('search')}
        </Link>
        <Link to="/products" className={isActive('/products')}>
          {t('products')}
        </Link>
        <Link to="/classes" className={isActive('/classes')}>
          {t('classes')}
        </Link>
      </nav>
    </>
  );
};

export default Header;