import React, { useState, useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';

const SearchPage = () => {
  const { t } = useLanguage();
  const [searchParams, setSearchParams] = useSearchParams();
  const [searchTerm, setSearchTerm] = useState(searchParams.get('q') || '');
  const [searchResults, setSearchResults] = useState([]);
  const [isLoading, setIsLoading] = useState(false);

  // Sample search data (in a real app, this would come from an API)
  const allRecipes = [
    { id: 1, name: 'Idli', category: 'Breakfast', image: 'https://via.placeholder.com/300x220/ff6b6b/white?text=Idli', time: '30 mins', calories: 120 },
    { id: 2, name: 'Dosa', category: 'Breakfast', image: 'https://via.placeholder.com/300x220/ffa500/white?text=Dosa', time: '25 mins', calories: 150 },
    { id: 3, name: 'Sambar', category: 'Curry', image: 'https://via.placeholder.com/300x220/32cd32/white?text=Sambar', time: '40 mins', calories: 180 },
    { id: 4, name: 'Rasam', category: 'Curry', image: 'https://via.placeholder.com/300x220/87ceeb/white?text=Rasam', time: '20 mins', calories: 80 },
    { id: 5, name: 'Curd Rice', category: 'Rice', image: 'https://via.placeholder.com/300x220/dda0dd/white?text=Curd+Rice', time: '10 mins', calories: 160 },
    { id: 6, name: 'Lemon Rice', category: 'Rice', image: 'https://via.placeholder.com/300x220/90ee90/white?text=Lemon+Rice', time: '15 mins', calories: 180 },
    { id: 7, name: 'Kothu Parotta', category: 'Street Food', image: 'https://via.placeholder.com/300x220/ff69b4/white?text=Kothu+Parotta', time: '30 mins', calories: 250 },
    { id: 8, name: 'Murukku', category: 'Snacks', image: 'https://via.placeholder.com/300x220/f0e68c/white?text=Murukku', time: '45 mins', calories: 200 },
    { id: 9, name: 'Medu Vada', category: 'Breakfast', image: 'https://via.placeholder.com/300x220/dc143c/white?text=Medu+Vada', time: '40 mins', calories: 180 },
    { id: 10, name: 'Ven Pongal', category: 'Breakfast', image: 'https://via.placeholder.com/300x220/ff4500/white?text=Ven+Pongal', time: '35 mins', calories: 200 },
    { id: 11, name: 'Coconut Rice', category: 'Rice', image: 'https://via.placeholder.com/300x220/ffd700/white?text=Coconut+Rice', time: '20 mins', calories: 200 },
    { id: 12, name: 'Tamarind Rice', category: 'Rice', image: 'https://via.placeholder.com/300x220/deb887/white?text=Tamarind+Rice', time: '25 mins', calories: 190 },
    { id: 13, name: 'Chettinad Chicken', category: 'Non-Veg', image: 'https://via.placeholder.com/300x220/4682b4/white?text=Chettinad+Chicken', time: '50 mins', calories: 300 },
    { id: 14, name: 'Ragi Dosa', category: 'Healthy', image: 'https://via.placeholder.com/300x220/98fb98/white?text=Ragi+Dosa', time: '30 mins', calories: 140 },
    { id: 15, name: 'Seedai', category: 'Snacks', image: 'https://via.placeholder.com/300x220/87ceeb/white?text=Seedai', time: '60 mins', calories: 180 }
  ];

  useEffect(() => {
    const query = searchParams.get('q');
    if (query) {
      setSearchTerm(query);
      performSearch(query);
    }
  }, [searchParams]);

  const performSearch = (query) => {
    setIsLoading(true);

    // Simulate API call delay
    setTimeout(() => {
      const filtered = allRecipes.filter(recipe =>
        recipe.name.toLowerCase().includes(query.toLowerCase()) ||
        recipe.category.toLowerCase().includes(query.toLowerCase())
      );
      setSearchResults(filtered);
      setIsLoading(false);
    }, 500);
  };

  const handleSearch = (e) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      setSearchParams({ q: searchTerm.trim() });
      performSearch(searchTerm.trim());
    }
  };

  const popularSearches = [
    'Idli', 'Dosa', 'Sambar', 'Rasam', 'Curd Rice', 
    'Lemon Rice', 'Kothu Parotta', 'Murukku', 'Chettinad Chicken'
  ];

  const handlePopularSearch = (term) => {
    setSearchTerm(term);
    setSearchParams({ q: term });
    performSearch(term);
  };

  return (
    <div className="home-container">
      <div style={{ textAlign: 'center', marginBottom: '30px' }}>
         <img 
  src="/image.png" 
  alt="Moushi Cookbook Logo" 
  className="home-logo"
  style={{ width: '60px', height: '60px', margin: '0 auto 15px' }}
  onError={(e) => {
    e.target.onerror = null; // prevent infinite loop
    e.target.src = '/images/photo.png'; // fallback if missing
  }} 
  />
        <h2 style={{ fontSize: '28px', color: '#333', marginBottom: '10px' }}>
          {t('search')}
        </h2>
        <p style={{ color: '#666', fontSize: '16px' }}>
          Find your favorite Tamil recipes
        </p>
      </div>

      {/* Search Bar */}
      <div className="search-section">
        <form className="search-bar" onSubmit={handleSearch}>
          <input
            type="text"
            placeholder={t('searchPlaceholder')}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <button type="submit">
            {t('searchButton')}
          </button>
        </form>
      </div>

      {/* Popular Searches */}
      {!searchParams.get('q') && (
        <div style={{ marginBottom: '40px', textAlign: 'center' }}>
          <h3 style={{ marginBottom: '20px', color: '#333' }}>Popular Searches</h3>
          <div style={{ 
            display: 'flex', 
            flexWrap: 'wrap', 
            justifyContent: 'center', 
            gap: '10px' 
          }}>
            {popularSearches.map((term) => (
              <button
                key={term}
                onClick={() => handlePopularSearch(term)}
                style={{
                  padding: '8px 16px',
                  background: '#f0f0f0',
                  border: 'none',
                  borderRadius: '20px',
                  cursor: 'pointer',
                  fontSize: '14px',
                  color: '#333',
                  transition: 'all 0.3s'
                }}
                onMouseOver={(e) => {
                  e.target.style.background = '#ff6b6b';
                  e.target.style.color = 'white';
                }}
                onMouseOut={(e) => {
                  e.target.style.background = '#f0f0f0';
                  e.target.style.color = '#333';
                }}
              >
                {term}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Loading State */}
      {isLoading && (
        <div className="loading">
          <div className="spinner"></div>
        </div>
      )}

      {/* Search Results */}
      {!isLoading && searchParams.get('q') && (
        <div>
          <div style={{ marginBottom: '20px' }}>
            <h3 style={{ color: '#333', fontSize: '20px' }}>
              Search Results for "{searchParams.get('q')}"
            </h3>
            <p style={{ color: '#666' }}>
              Found {searchResults.length} recipes
            </p>
          </div>

          {searchResults.length > 0 ? (
            <div className="recipes-grid">
              {searchResults.map((recipe) => (
                <div key={recipe.id} className="recipe-card">
                  <Link to={`/recipe/${recipe.id}`}>
                    <img
                      src={recipe.image}
                      alt={recipe.name}
                      className="recipe-image"
                    />
                  </Link>
                  <div className="recipe-info">
                    <h4>{recipe.name}</h4>
                    <div style={{ 
                      fontSize: '12px', 
                      color: '#ff6b6b', 
                      fontWeight: '600',
                      marginBottom: '8px'
                    }}>
                      {recipe.category}
                    </div>
                    <div className="recipe-meta">
                      <span className="recipe-time">{recipe.time}</span>
                      <span className="recipe-calories">{recipe.calories} cal</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div style={{ 
              textAlign: 'center', 
              padding: '50px', 
              background: 'white',
              borderRadius: '15px',
              boxShadow: '0 4px 15px rgba(0,0,0,0.1)'
            }}>
              <div style={{ fontSize: '48px', marginBottom: '20px' }}>🔍</div>
              <h3 style={{ color: '#333', marginBottom: '10px' }}>
                No recipes found
              </h3>
              <p style={{ color: '#666', marginBottom: '20px' }}>
                Try searching for something else or check out our popular recipes
              </p>
              <div style={{ 
                display: 'flex', 
                flexWrap: 'wrap', 
                justifyContent: 'center', 
                gap: '10px' 
              }}>
                {popularSearches.slice(0, 5).map((term) => (
                  <button
                    key={term}
                    onClick={() => handlePopularSearch(term)}
                    style={{
                      padding: '8px 16px',
                      background: '#ff6b6b',
                      color: 'white',
                      border: 'none',
                      borderRadius: '20px',
                      cursor: 'pointer',
                      fontSize: '14px'
                    }}
                  >
                    {term}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Recipe Categories for Discovery */}
      {!searchParams.get('q') && (
        <div style={{ marginTop: '40px' }}>
          <h3 style={{ textAlign: 'center', marginBottom: '20px', color: '#333' }}>
            Browse by Category
          </h3>
          <div style={{ 
            display: 'grid', 
            gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))', 
            gap: '15px' 
          }}>
            {['Breakfast', 'Rice', 'Curry', 'Snacks', 'Street Food', 'Healthy'].map((category) => (
              <div
                key={category}
                onClick={() => handlePopularSearch(category)}
                style={{
                  padding: '20px',
                  background: 'white',
                  borderRadius: '10px',
                  textAlign: 'center',
                  cursor: 'pointer',
                  boxShadow: '0 4px 15px rgba(0,0,0,0.1)',
                  transition: 'transform 0.3s'
                }}
                onMouseOver={(e) => {
                  e.currentTarget.style.transform = 'translateY(-5px)';
                }}
                onMouseOut={(e) => {
                  e.currentTarget.style.transform = 'translateY(0)';
                }}
              >
                <div style={{ fontSize: '24px', marginBottom: '10px' }}>
                  {category === 'Breakfast' && '🌅'}
                  {category === 'Rice' && '🍚'}
                  {category === 'Curry' && '🍛'}
                  {category === 'Snacks' && '🥨'}
                  {category === 'Street Food' && '🍜'}
                  {category === 'Healthy' && '🥗'}
                </div>
                <h4 style={{ color: '#333', fontSize: '16px' }}>{category}</h4>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default SearchPage;