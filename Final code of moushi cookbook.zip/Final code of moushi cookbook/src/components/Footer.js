import React from 'react';
import { useLanguage } from '../context/LanguageContext';

const Footer = () => {
  const { t } = useLanguage();

  return (
    <footer className="footer">
      <div className="footer-content">
          <img 
  src="/image.png" 
  alt="Moushi Cookbook Logo" 
  className="footer-logo"
  style={{ width: '60px', height: '60px', margin: '0 auto 15px' }}
  onError={(e) => {
    e.target.onerror = null; // prevent infinite loop
    e.target.src = '/images/photo.png'; // fallback if missing
  }}
        />
        <h3>Moushi Cookbook</h3>
        <p>Your ultimate destination for authentic Tamil recipes and cooking techniques</p>

        <div className="footer-links">
          <a href="#about">{t('aboutUs')}</a>
          <a href="#contact">{t('contactUs')}</a>
          <a href="#privacy">{t('privacyPolicy')}</a>
          <a href="#terms">{t('termsOfService')}</a>
        </div>

        <div style={{ marginTop: '20px', fontSize: '14px', color: '#999' }}>
          © 2025 Moushi Cookbook. {t('allRightsReserved')}.
        </div>
      </div>
    </footer>
  );
};

export default Footer;