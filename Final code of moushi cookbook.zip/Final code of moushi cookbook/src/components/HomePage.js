import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';

const HomePage = () => {
  const { t } = useLanguage();
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');

  const handleSearch = (e) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchTerm.trim())}`);
    }
  };

  const categories = [
    {
      name: 'favoriteRecipes',
      displayName: t('favoriteRecipes'),
      image: 'https://static.vecteezy.com/system/resources/previews/013/195/659/original/restaurant-delicious-food-logo-badge-line-style-design-with-smile-face-fork-and-spoon-icon-concept-for-catering-food-culinary-logo-design-vector.jpg',
      description: 'All your liked recipes in one place',
      count: 25,
      recipes: ['Dosa','idli']
    },
    {
      name: 'mostPopularRecipes',
      displayName: t('mostPopularRecipes'),
      image: 'https://static.vecteezy.com/system/resources/previews/024/342/968/large_2x/top-view-of-party-brunch-big-buffet-table-setting-with-food-meat-and-salad-photo.jpg',
      description: 'Traditional Tamil recipes loved by many',
      count: 25,
      recipes: [
        'Idli', 'Dosa', 'Medu Vada', 'Ven Pongal', 'Uttapam', 
        'Sambar', 'Rasam', 'Vatha Kuzhambu', 'Puli Kuzhambu', 'More Kuzhambu',
        'Curd Rice (Thayir Sadam)', 'Tamarind Rice (Puliyodharai)', 'Lemon Rice',
        'Tomato Rice', 'Coconut Rice', 'Bisi Bele Bath', 'Chettinad Chicken Curry',
        'Mutton Kuzhambu', 'Meen Kuzhambu', 'Prawn Masala', 'Kothu Parotta',
        'Murukku', 'Seedai', 'Adirasam', 'Sakkarai Pongal'
      ]
    },
    {
      name: 'trendingRecipes',
      displayName: t('trendingRecipes'),
      image: 'https://img.freepik.com/premium-photo/top-view-arrangement-different-foods-table_198067-566487.jpg',
      description: 'Modern fusion and trending Tamil dishes',
      count: 25,
      recipes: [
        'Avial', 'Kootu', 'Ven Pongal', 'Sakkarai Pongal', 'Millet Pongal',
        'Millet Payasam', 'Idli Sliders', 'Masala Dosa Tacos', 'Chettinad Pasta',
        'Kothu Parotta', 'Ambur Biryani', 'Dindigul Biryani', 'Chettinad Biryani',
        'Perun Soru Biryani', 'Meen Kuzhambu Pasta', 'Paya Ramen', 'Kimchi Curd Rice',
        'Shawarma Parotta', 'Curd Rice (Thayir Sadam)', 'Fried Curd Rice',
        'Chettinad Chicken Curry', 'Mushroom Chettinad', 'Chettinad Fish Fry',
        'Chettinad Egg Curry', 'Kuzhi Paniyaram'
      ]
    },
    {
      name: 'easytoCook',
      displayName: t('easytoCook'),
      image: 'https://www.metropolbanquet.com/wp-content/uploads/wedding-reception-food-serving-style.jpg',
      description: 'Simple and quick Tamil recipes for beginners',
      count: 25,
      recipes: [
        'Lemon Rice', 'Curd Rice (Thayir Sadam)', 'Tamarind Rice (Puliyodharai)',
        'Coconut Rice', 'Tomato Rice', 'Vegetable Upma', 'Rava Kesari'
      ]
    },
    {
      name: 'lunchbox',
      displayName: t('lunchbox'),
      image: 'https://tiffycooks.com/wp-content/uploads/2022/09/2BE6E57C-00A6-4C4A-8D60-EE9E384CCEED-1536x2048.jpg',
      description: 'Perfect recipes for office and school lunch boxes',
      count: 25,
      recipes: [
        'Lemon Rice', 'Tamarind Rice (Puliyodharai)', 'Coconut Rice',
        'Tomato Rice', 'Curd Rice (Thayir Sadam)', 'Sambar Sadam'
      ]
    },
    {
      name: 'healthyRecipes',
      displayName: t('healthyRecipes'),
      image: 'https://imgmedia.lbb.in/media/2019/06/5d00c68beec51b66cfad779c_1560331915441.jpg',
      description: 'Nutritious and health-conscious Tamil recipes',
      count: 25,
      recipes: [
        'Ragi Koozh (Finger Millet Porridge)', 'Ragi Dosa', 'Ragi Idiyappam',
        'Kambu Sadam (Pearl Millet Rice)', 'Kambu Koozh', 'Thinai Pongal'
      ]
    },
    {
      name: 'breakfastRecipes',
      displayName: t('breakfastRecipes'),
      image: 'https://img.freepik.com/premium-photo/group-south-indian-food-like-masala-dosa-uttapam-idli-idly-wada-vada-sambar-appam-semolina-halwa-upma-served-banana-leaf-with-colourful-chutneys-selective-focus_466689-25669.jpg?w=2000',
      description: 'Traditional Tamil breakfast dishes',
      count: 25,
      recipes: [
        'Idli', 'Dosa', 'Rava Dosa', 'Onion Uttapam', 'Ven Pongal',
        'Medu Vada', 'Idiyappam with Coconut Milk'
      ]
    },
    {
      name: 'gymGoers',
      displayName: t('gymGoers'),
      image: 'https://www.pazhayasoru.com/wp-content/uploads/2022/01/kambu-koozh-img2.jpg',
      description: 'High protein Tamil recipes for fitness enthusiasts',
      count: 25,
      recipes: [
        'Ragi Malt (Ragi Koozh with buttermilk)', 'Ragi Dosa', 'Ragi Idli',
        'Kambu (Pearl Millet) Upma', 'Thinai Pongal (Foxtail Millet Pongal)'
      ]
    },
    {
      name: 'snacksRecipe',
      displayName: t('snacksRecipe'),
      image: 'https://as1.ftcdn.net/v2/jpg/05/08/40/68/1000_F_508406848_En3Kx4w9gmJI6K3uRxWE8fDBdKWRdQOc.jpg',
      description: 'Traditional Tamil snacks and evening treats',
      count: 25,
      recipes: [
        'Murukku', 'Thenkuzhal Murukku', 'Kai Murukku', 'Seedai (Uppu / Vella)',
        'Thattai', 'Ribbon Pakoda', 'Omapodi (Sev)'
      ]
    },
    {
      name: 'streetFood',
      displayName: t('streetFood'),
      image: 'https://static.vecteezy.com/system/resources/previews/031/584/006/non_2x/ai-generative-image-of-a-bustling-japanese-street-food-market-free-photo.jpg',
      description: 'Popular Tamil street food favorites',
      count: 25,
      recipes: [
        'Kothu Parotta', 'Kari Dosa (Madurai Special)', 'Idiyappam Kothu',
        'Parotta with Salna', 'Egg Kalakki (Madurai Style)'
      ]
    },
    {
      name: 'baking',
      displayName: t('baking'),
      image: 'https://blog.udemy.com/wp-content/uploads/2014/06/shutterstock_111120644.jpg',
      description: 'Baking recipes with Tamil fusion touches',
      count: 25,
      recipes: [
        'Vanilla Sponge Cake', 'Chocolate Cake', 'Marble Cake', 'Carrot Cake',
        'Banana Cake', 'Plum Cake (Christmas Special)'
      ]
    },
    {
      name: 'internationalCuisine',
      displayName: t('internationalCuisine'),
      image: 'https://soyummy.com/wp-content/uploads/2024/03/different-countries-cuisine-varied-dishes-prepared-form-meat-or-vegetables-stockpack-istock-scaled.jpg',
      description: 'Global cuisine with Tamil cooking techniques',
      count: 25,
      recipes: [
        'Spaghetti Aglio e Olio', 'Margherita Pizza', 'Lasagna', 'Fried Rice',
        'Schezwan Noodles', 'Sushi (Maki Roll)'
      ]
    }
  ];

  return (
    <div className="home-container">
      <div className="welcome-section">
       <img 
  src="/image.png" 
  alt="Moushi Cookbook Logo" 
  className="logo"
  style={{ width: '60px', height: '60px', margin: '0 auto 15px' }}
  onError={(e) => {
    e.target.onerror = null; // prevent infinite loop
    e.target.src = '/images/photo.png'; // fallback if missing
  }}
        />
        <h2>{t('welcomeTitle')}</h2>
        <p>{t('welcomeSubtitle')}</p>
      </div>

      <div className="search-section">
        <form className="search-bar" onSubmit={handleSearch}>
          <input
            type="text"
            placeholder={t('searchPlaceholder')}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <button type="submit">
            {t('searchButton')}
          </button>
        </form>
      </div>

      <div className="categories-section">
        <h3>{t('categories')}</h3>
        <div className="categories-grid">
          {categories.map((category) => (
            <Link
              key={category.name}
              to={`/category/${category.name}`}
              className="category-card"
            >
          <img
  src={category.image}
  alt={category.name}
  style={{
    width: '100%',
    maxWidth: '600px',
    height: '400px',
    objectFit: 'cover',
    borderRadius: '15px',
    boxShadow: '0 10px 30px rgba(0,0,0,0.1)'
  }}
  onError={(e) => {
    e.target.src = '/images/photo.jpg'; // Local fallback image
  }}
              />
              <div className="category-info">
                <h4>{category.displayName}</h4>
                <p>{category.description}</p>
                <div className="recipe-count">
                  {category.count} recipes
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
};

export default HomePage;