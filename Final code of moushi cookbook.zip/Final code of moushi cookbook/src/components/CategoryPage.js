import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';

const CategoryPage = () => {
  const { categoryName } = useParams();
  const { t } = useLanguage();
  const [recipes, setRecipes] = useState([]);
  const [favorites, setFavorites] = useState([]);

  // Sample recipe data with all categories
  const allRecipes = {
    mostPopularRecipes: [
      { id: 1, name: 'Idli', image: 'https://www.tomatoblues.com/wp-content/uploads/2018/07/SAMAI-IDLI-1-scaled.jpg', time: '30 mins', calories: 120 },
      { id: 2, name: 'Dosa', image: 'https://png.pngtree.com/thumb_back/fh260/background/20230612/pngtree-plate-of-dosa-with-sauce-on-top-image_2892701.jpg', time: '25 mins', calories: 150 },
      { id: 3, name: 'Medu Vada', image: 'https://i.pinimg.com/originals/22/c3/b7/22c3b7e9c6aa727c9168656c4e1ac0e6.jpg', time: '40 mins', calories: 180 },
      { id: 4, name: 'Ven Pongal', image: 'https://www.indianhealthyrecipes.com/wp-content/uploads/2021/01/pongal-ven-pongal.jpg', time: '35 mins', calories: 200 },
      { id: 5, name: 'Uttapam', image: 'https://www.cookingcarnival.com/wp-content/uploads/2022/02/Uttapam-1.jpg', time: '20 mins', calories: 140 },
      // Add more recipes as needed
    ],
    trendingRecipes: [
      { id: 201, name: 'Avial', image: 'https://easyday.snydle.com/files/2015/03/Avial.jpg', time: '45 mins', calories: 160 },
      { id: 202, name: 'Kootu', image: 'https://3.bp.blogspot.com/-68Qz0RPvC1I/UmUDsB4e-MI/AAAAAAAABzU/duKRLXDdXDY/s1600/Podalangai+Kootu.jpg', time: '30 mins', calories: 140 },
      { id: 203, name: 'Ven pongal', image: 'https://www.indianhealthyrecipes.com/wp-content/uploads/2021/01/pongal-ven-pongal.jpg', time: '35 mins', calories: 200 },
      { id: 204, name: 'Sakkarai Pongal', image: 'https://priyakitchenette.com/wp-content/uploads/2013/08/sakkarai-pongal-recipe.jpg', time: '40 mins', calories: 350 },
      { id: 205, name: 'Millet Pongal', image: 'https://vismaifood.com/storage/app/uploads/public/0ad/d04/0dc/thumb__1200_0_0_0_auto.jpg', time: '25 mins', calories: 220 },
    ],
    easytoCook: [
      { id: 301, name: 'Lemon Rice', image: 'https://www.spiceupthecurry.com/wp-content/uploads/2012/07/indian-lemon-rice-1.jpg', time: '15 mins', calories: 180 },
      { id: 302, name: 'Curd Rice', image: 'https://www.indianhealthyrecipes.com/wp-content/uploads/2022/02/curd-rice-thayir-sadam.jpg', time: '10 mins', calories: 160 },
      { id: 303, name: 'Tamarind Rice', image: 'https://smithakalluraya.com/wp-content/uploads/2020/03/puliyogare.jpg', time: '20 mins', calories: 190 },
    ],
    lunchbox: [
      { id: 401, name:'Coconut Rice', image: 'https://www.gimmesomeoven.com/wp-content/uploads/2023/01/Coconut-Rice-Recipe-9-1100x1650.jpg', time: '15 mins', calories: 200 },
      { id: 402, name: 'Tomato Rice', image: 'https://assets.bonappetit.com/photos/5f315fa5459e181dafb1c526/1:1/w_2560%2Cc_limit/HLY-FMC-Tomato-Rice-16x9.jpg', time: '10 mins', calories: 170 },
      { id: 403, name: 'Curd Rice', image: 'https://www.indianhealthyrecipes.com/wp-content/uploads/2022/02/curd-rice-thayir-sadam.jpg', time: '20 mins', calories: 160 },
    ],
    healthyRecipes: [
      { id: 501, name: 'Ragi Koozh', image: 'https://farm4.staticflickr.com/3863/14769235856_69aa4728e2_c.jpg', time: '25 mins', calories: 120 },
      { id: 502, name: 'Ragi Dosa', image: 'https://www.kuchpakrahahai.in/wp-content/uploads/2020/10/Instant_Ragi_Dosa_1.jpg', time: '30 mins', calories: 140 },
      { id: 503, name: 'Kambu Sadam', image: 'https://farm3.staticflickr.com/2897/14318869357_217840dd95_o.jpg', time: '35 mins', calories: 160 },
    ],
    breakfastRecipes: [
      { id: 601, name: 'Rava Dosa', image: 'https://www.kuchpakrahahai.in/wp-content/uploads/2020/10/Instant_Ragi_Dosa_1.jpg', time: '30 mins', calories: 160 },
      { id: 602, name: 'Onion Uttapam', image: 'https://www.qualityfoodproducts.com/admin/upload/recipes/5e43ef2d3ca71.jpg', time: '25 mins', calories: 140 },
      { id: 603, name: 'Ven Pongal', image: 'https://drishtidarshan.com/wp-content/uploads/2021/01/1-vn-pongal.jpg', time: '20 mins', calories: 200 },
    ],
    gymGoers: [
      { id: 701, name: 'Ragi Malt', image: 'https://www.theculinarypeace.com/wp-content/uploads/2020/06/Ragi-Malt-1474x2048.jpg', time: '30 mins', calories: 160 },
      { id: 702, name: 'Ragi Dosa', image: 'https://farm5.staticflickr.com/4668/40112901962_ace304ac88_o.jpg', time: '25 mins', calories: 140 },
      { id: 703, name: 'Ragi Idli', image: 'https://www.secondrecipe.com/wp-content/uploads/2024/02/ragi-idli.jpg', time: '20 mins', calories: 130 },
    ],
    snacksRecipe: [
      { id: 801, name: 'Murukku', image: 'https://www.snacksbazzar.com/wp-content/uploads/2020/09/MURUKKU1.jpg', time: '45 mins', calories: 190 },
      { id: 802, name: 'Seedai', image: 'https://www.sharmispassions.com/wp-content/uploads/2022/08/uppu-seedai1.jpg', time: '60 mins', calories: 170 },
      { id: 803, name: 'Thattai', image: 'https://www.indianhealthyrecipes.com/wp-content/uploads/2019/10/thattai.jpg', time: '40 mins', calories: 160 },
    ],
    streetFood: [
      { id: 901, name: 'Kothu Parotta', image: 'https://www.relishthebite.com/wp-content/uploads/2015/05/Kothuparotta9.jpg', time: '30 mins', calories: 350 },
      { id: 902, name: 'Kari Dosa', image: 'https://i.ytimg.com/vi/5q2JnNhQyzs/maxresdefault.jpg', time: '35 mins', calories: 280 },
      { id: 903, name: 'Parotta with salna', image: 'https://farm9.staticflickr.com/8628/16023206193_a6fd1310de_o.jpg', time: '60 mins', calories: 320 },
    ],
    baking: [
      { id: 1001, name: 'Vanilla Sponge Cake', image: 'https://www.keralacookingrecipes.com/wp-content/uploads/2019/01/vanilla-sponge-cake.jpg', time: '60 mins', calories: 280 },
      { id: 1002, name: 'Chocolate Cake', image: 'https://www.valyastasteofhome.com/wp-content/uploads/2016/05/The-Best-Chocolate-Sponge-Cake-No-Oil-3.jpg', time: '70 mins', calories: 320 },
      { id: 1003, name: 'Carrot Cake', image: 'https://www.modernhoney.com/wp-content/uploads/2019/04/The-Best-Carrot-Cake-Recipe9.jpg', time: '65 mins', calories: 290 },
    ],
    internationalCuisine: [
      { id: 1101, name: 'Spaghetti Aglio e Olio', image: 'https://essenrezept.de/wp-content/uploads/2021/03/Spaghetti-aglio-e-olio-2-1527x2048.jpg', time: '20 mins', calories: 350 },
      { id: 1102, name: 'Margherita Pizza', image: 'https://www.inspiredtaste.net/wp-content/uploads/2023/09/Margherita-Pizza-5-1200.jpg', time: '45 mins', calories: 400 },
      { id: 1103, name: 'Lasagna', image: 'https://www.recetasdesbieta.com/wp-content/uploads/2018/10/lasagna-original..jpg', time: '45 mins', calories: 450 },
    ]
  };

  useEffect(() => {
    // Load recipes for the current category
    const categoryRecipes = allRecipes[categoryName] || [];
    setRecipes(categoryRecipes);

    // Load favorites from localStorage
    const savedFavorites = JSON.parse(localStorage.getItem('favorites') || '[]');
    setFavorites(savedFavorites);
  }, [categoryName]);

  const toggleFavorite = (recipeId) => {
    const newFavorites = favorites.includes(recipeId)
      ? favorites.filter(id => id !== recipeId)
      : [...favorites, recipeId];

    setFavorites(newFavorites);
    localStorage.setItem('favorites', JSON.stringify(newFavorites));
  };

  const getCategoryDisplayName = () => {
    const categoryMap = {
      mostPopularRecipes: t('mostPopularRecipes'),
      trendingRecipes: t('trendingRecipes'),
      easytoCook: t('easytoCook'),
      lunchbox: t('lunchbox'),
      healthyRecipes: t('healthyRecipes'),
      breakfastRecipes: t('breakfastRecipes'),
      gymGoers: t('gymGoers'),
      snacksRecipe: t('snacksRecipe'),
      streetFood: t('streetFood'),
      baking: t('baking'),
      internationalCuisine: t('internationalCuisine')
    };
    return categoryMap[categoryName] || categoryName;
  };

  return (
    <div className="home-container">
      <div style={{ marginBottom: '30px' }}>
        <h2 style={{ fontSize: '28px', color: '#333', marginBottom: '10px' }}>
          {getCategoryDisplayName()}
        </h2>
        <p style={{ color: '#666', fontSize: '16px' }}>
          Discover {recipes.length} amazing recipes in this category
        </p>
      </div>

      <div className="recipes-grid">
        {recipes.map((recipe) => (
          <div key={recipe.id} className="recipe-card">
            <Link to={`/recipe/${recipe.id}`}>
              <img
  src={recipe.image}
  alt={recipe.name}
  style={{
    width: '100%',
    maxWidth: '600px',
    height: '400px',
    objectFit: 'cover',
    borderRadius: '15px',
    boxShadow: '0 10px 30px rgba(0,0,0,0.1)'
  }}
  onError={(e) => {
    e.target.src = '/images/photo.jpg'; // Local fallback image
  }}
  />
   <img 
  src="/image.png" 
  alt="Moushi Cookbook Logo" 
  className="logo"
  style={{ width: '60px', height: '60px', margin: '0 auto 15px' }}
  onError={(e) => {
    e.target.onerror = null; // prevent infinite loop
    e.target.src = '/images/photo.png'; // fallback if missing
  }}
              />
            </Link>
            <div className="recipe-info">
              <h4>{recipe.name}</h4>
              <div className="recipe-meta">
                <span className="recipe-time">{recipe.time}</span>
                <span className="recipe-calories">{recipe.calories} cal</span>
                <button
                  className={`favorite-btn ${favorites.includes(recipe.id) ? 'active' : ''}`}
                  onClick={() => toggleFavorite(recipe.id)}
                  title={favorites.includes(recipe.id) ? 'Remove from favorites' : 'Add to favorites'}
                >
                  {favorites.includes(recipe.id) ? '❤️' : '🤍'}
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {recipes.length === 0 && (
        <div style={{ textAlign: 'center', padding: '50px', color: '#666' }}>
          <h3>No recipes found in this category</h3>
          <p>Please check back later for new recipes!</p>
        </div>
      )}
    </div>
  );
};

export default CategoryPage;