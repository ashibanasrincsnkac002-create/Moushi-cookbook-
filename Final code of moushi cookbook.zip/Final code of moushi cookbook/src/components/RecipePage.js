
import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';

const RecipePage = () => {
  const { recipeId } = useParams();
  const { t } = useLanguage();
  const [recipe, setRecipe] = useState(null);
  const [isFavorite, setIsFavorite] = useState(false);

  // Sample detailed recipe data
  const recipeData = {
    1: {
      id: 1,
      name: 'Idli',
      image: 'https://www.tomatoblues.com/wp-content/uploads/2018/07/SAMAI-IDLI-1-scaled.jpg',
      description: 'Soft and fluffy steamed rice cakes, a staple South Indian breakfast',
      cookingTime: '30 minutes',
      prepTime: '8-10 hours (for fermentation)',
      servings: '4-6 people',
      calories: 120,
      difficulty: 'Easy',
      ingredients: [
        '3 cups Idli rice',
        '1 cup Urad dal (black gram)',
        '1/2 tsp Fenugreek seeds',
        '1 tsp Salt',
        'Water as needed',
        'Oil for greasing'
      ],
      instructions: [
        'Wash and soak idli rice and urad dal separately for 4-6 hours',
        'Grind urad dal with fenugreek seeds to a smooth, fluffy batter',
        'Grind rice to a slightly coarse paste',
        'Mix both batters, add salt, and ferment for 8-10 hours',
        'Grease idli molds and pour batter',
        'Steam for 10-12 minutes until cooked',
        'Serve hot with sambar and coconut chutney'
      ],
      videoUrl: 'https://www.youtube.com/embed/Ayo80PIb-Qg',
      chef: 'Traditional Recipe',
      tags: ['Breakfast', 'Steamed', 'Fermented', 'Gluten-free']
    },
    2: {
      id: 2,
      name: 'Dosa',
      image: 'https://png.pngtree.com/thumb_back/fh260/background/20230612/pngtree-plate-of-dosa-with-sauce-on-top-image_2892701.jpg',
      description: 'Crispy fermented crepe made from rice and lentil batter',
      cookingTime: '25 minutes',
      prepTime: '8-10 hours (for fermentation)',
      servings: '4 people',
      calories: 150,
      difficulty: 'Medium',
      ingredients: [
        '3 cups Dosa rice',
        '1 cup Urad dal',
        '1/2 tsp Fenugreek seeds',
        '1 tsp Salt',
        'Oil for cooking',
        'Water as needed'
      ],
      instructions: [
        'Prepare fermented batter same as idli',
        'Heat a non-stick pan or cast iron tawa',
        'Pour a ladle of batter and spread in circular motion',
        'Drizzle oil around the edges',
        'Cook until golden brown and crispy',
        'Fold and serve with sambar and chutney'
      ],
      videoUrl: 'https://www.youtube.com/embed/AssLX3HjowM',
      chef: 'Traditional Recipe',
      tags: ['Breakfast', 'Crispy', 'Fermented']
    },
    3: {
  id: 3,
  name: 'Medu Vadai',
  image: 'https://i.pinimg.com/originals/22/c3/b7/22c3b7e9c6aa727c9168656c4e1ac0e6.jpg',
  description: 'Crispy and soft South Indian lentil doughnuts',
  cookingTime: '20 minutes',
  prepTime: '8 hours (for soaking and fermentation)',
  servings: '4 people',
  calories: 200,
  difficulty: 'Medium',
  ingredients: [
    '2 cups Urad dal',
    '1 tsp Black peppercorns',
    '1 tsp Cumin seeds',
    '2 Green chilies, chopped',
    '1-inch Ginger, chopped',
    'Salt to taste',
    'Oil for deep frying',
    'Curry leaves (optional)'
  ],
  instructions: [
    'Soak urad dal for 6-8 hours',
    'Grind into a smooth batter',
    'Mix in salt, green chilies, ginger, pepper, and curry leaves',
    'Heat oil in a deep pan',
    'Shape batter into doughnuts and fry until golden brown',
    'Serve hot with coconut chutney or sambar'
  ],
  videoUrl: 'https://www.youtube.com/embed/Zjm9fQBBHiM',
  chef: 'Traditional Recipe',
  tags: ['Snack', 'Crispy', 'South Indian']
},

4: {
  id: 4,
  name: 'Ven Pongal',
  image: 'https://www.indianhealthyrecipes.com/wp-content/uploads/2021/01/pongal-ven-pongal.jpg',
  description: 'Soft and savory South Indian rice and lentil porridge',
  cookingTime: '25 minutes',
  prepTime: '10 minutes',
  servings: '4 people',
  calories: 220,
  difficulty: 'Easy',
  ingredients: [
    '1 cup Rice',
    '1/4 cup Moong dal',
    '1 tsp Black peppercorns',
    '1 tsp Cumin seeds',
    '1-inch Ginger, grated',
    '10-12 Cashews',
    '2 tbsp Ghee',
    'Salt to taste',
    'Water as needed'
  ],
  instructions: [
    'Roast moong dal until fragrant',
    'Cook rice and moong dal together until soft',
    'In a pan, heat ghee and fry cashews until golden',
    'Add cumin, pepper, and ginger, sauté for a minute',
    'Mix tempering with cooked rice and dal',
    'Serve hot with coconut chutney or sambar'
  ],
  videoUrl: 'https://www.youtube.com/embed/GLSSQn4P8rg',
  chef: 'Traditional Recipe',
  tags: ['Breakfast', 'Soft', 'Savory']
},

5: {
  id: 5,
  name: 'Uttapam',
  image: 'https://www.cookingcarnival.com/wp-content/uploads/2022/02/Uttapam-1.jpg',
  description: 'Thick South Indian pancake topped with vegetables',
  cookingTime: '15 minutes',
  prepTime: '8-10 hours (for fermentation)',
  servings: '4 people',
  calories: 180,
  difficulty: 'Medium',
  ingredients: [
    '2 cups Dosa batter',
    '1 small Onion, finely chopped',
    '1 small Tomato, finely chopped',
    '1 Green chili, finely chopped',
    '1/4 cup Capsicum, finely chopped',
    'Fresh coriander leaves, chopped',
    'Salt to taste',
    'Oil for cooking'
  ],
  instructions: [
    'Prepare fermented dosa batter',
    'Heat a non-stick pan or tawa',
    'Pour a ladle of batter and spread slightly thick',
    'Sprinkle chopped vegetables on top',
    'Drizzle oil around edges',
    'Cook until bottom is golden, then flip and cook lightly',
    'Serve hot with sambar and chutney'
  ],
  videoUrl: 'https://www.youtube.com/embed/2IT1Osvuydw',
  chef: 'Traditional Recipe',
  tags: ['Breakfast', 'Vegetables', 'South Indian']
},
201: {
  id: 201,
  name: 'Avial',
  image: 'https://easyday.snydle.com/files/2015/03/Avial.jpg',
  description: 'Mixed vegetables cooked in coconut and yogurt, seasoned with curry leaves',
  cookingTime: '25 minutes',
  prepTime: '10 minutes',
  servings: '4 people',
  calories: 180,
  difficulty: 'Medium',
  ingredients: [
    '1 cup Carrot, chopped',
    '1 cup Beans, chopped',
    '1 cup Drumstick, chopped',
    '1 cup Raw banana, chopped',
    '1/2 cup Grated coconut',
    '1 tsp Cumin seeds',
    '1 cup Yogurt',
    '2 tbsp Coconut oil',
    'Curry leaves',
    'Salt to taste'
  ],
  instructions: [
    'Cook vegetables until tender',
    'Grind coconut and cumin seeds to a paste',
    'Add coconut paste to vegetables and cook for 2-3 minutes',
    'Add yogurt and mix gently',
    'Drizzle coconut oil and add curry leaves',
    'Serve hot'
  ],
  videoUrl: 'https://www.youtube.com/embed/dIlLMl6-Om0',
  chef: 'Traditional Recipe',
  tags: ['Vegetable', 'South Indian', 'Healthy']
},

202: {
  id: 202,
  name: 'Kootu',
  image: 'https://3.bp.blogspot.com/-68Qz0RPvC1I/UmUDsB4e-MI/AAAAAAAABzU/duKRLXDdXDY/s1600/Podalangai+Kootu.jpg',
  description: 'South Indian lentil and vegetable stew with coconut and spices',
  cookingTime: '20 minutes',
  prepTime: '10 minutes',
  servings: '4 people',
  calories: 160,
  difficulty: 'Medium',
  ingredients: [
    '1 cup Moong dal or Toor dal',
    '2 cups Mixed vegetables (carrot, beans, pumpkin)',
    '1/2 cup Grated coconut',
    '1 tsp Cumin seeds',
    '1/2 tsp Turmeric powder',
    '2 Green chilies',
    '1 tsp Oil',
    'Curry leaves',
    'Salt to taste'
  ],
  instructions: [
    'Cook dal and vegetables until soft',
    'Grind coconut, cumin, and green chilies into a paste',
    'Add paste to cooked dal and vegetables',
    'Simmer for 5 minutes',
    'Tempering with oil, curry leaves, and mustard seeds',
    'Serve hot with rice'
  ],
  videoUrl: 'https://www.youtube.com/embed/qX5DUbJaWQM',
  chef: 'Traditional Recipe',
  tags: ['Dal', 'Vegetable', 'South Indian']
},

203: {
  id: 203,
  name: 'Ven Pongal',
  image: 'https://www.indianhealthyrecipes.com/wp-content/uploads/2021/01/pongal-ven-pongal.jpg',
  description: 'Soft and savory South Indian rice and lentil porridge',
  cookingTime: '25 minutes',
  prepTime: '10 minutes',
  servings: '4 people',
  calories: 220,
  difficulty: 'Easy',
  ingredients: [
    '1 cup Rice',
    '1/4 cup Moong dal',
    '1 tsp Black peppercorns',
    '1 tsp Cumin seeds',
    '1-inch Ginger, grated',
    '10-12 Cashews',
    '2 tbsp Ghee',
    'Salt to taste',
    'Water as needed'
  ],
  instructions: [
    'Roast moong dal until fragrant',
    'Cook rice and moong dal together until soft',
    'In a pan, heat ghee and fry cashews until golden',
    'Add cumin, pepper, and ginger, sauté for a minute',
    'Mix tempering with cooked rice and dal',
    'Serve hot with coconut chutney or sambar'
  ],
  videoUrl: 'https://www.youtube.com/embed/GLSSQn4P8rg',
  chef: 'Traditional Recipe',
  tags: ['Breakfast', 'Soft', 'Savory']
},

204: {
  id: 204,
  name: 'Sakkarai Pongal',
  image: 'https://priyakitchenette.com/wp-content/uploads/2013/08/sakkarai-pongal-recipe.jpg',
  description: 'Sweet South Indian rice and lentil dish flavored with jaggery, ghee, and nuts',
  cookingTime: '25 minutes',
  prepTime: '10 minutes',
  servings: '4 people',
  calories: 300,
  difficulty: 'Medium',
  ingredients: [
    '1 cup Rice',
    '1/4 cup Moong dal',
    '1 cup Jaggery, grated',
    '2 tbsp Ghee',
    '10 Cashews',
    '10 Raisins',
    '1/2 tsp Cardamom powder',
    'Water as needed'
  ],
  instructions: [
    'Cook rice and moong dal until soft',
    'Dissolve jaggery in a little water and strain',
    'Add jaggery syrup to cooked rice and dal, mix well',
    'In a pan, heat ghee and fry cashews and raisins',
    'Add cardamom powder and mix with pongal',
    'Serve warm'
  ],
  videoUrl: 'https://www.youtube.com/embed/6IgXW_5YlI4',
  chef: 'Traditional Recipe',
  tags: ['Sweet', 'Festival', 'South Indian']
},

205: {
  id: 205,
  name: 'Millet Pongal',
  image: 'https://vismaifood.com/storage/app/uploads/public/0ad/d04/0dc/thumb__1200_0_0_0_auto.jpg',
  description: 'Healthy South Indian porridge made with millet and lentils',
  cookingTime: '25 minutes',
  prepTime: '10 minutes',
  servings: '4 people',
  calories: 200,
  difficulty: 'Easy',
  ingredients: [
    '1 cup Millet (Foxtail/Barnyard)',
    '1/4 cup Moong dal',
    '1 tsp Black pepper',
    '1 tsp Cumin seeds',
    '1-inch Ginger, grated',
    '2 tbsp Ghee',
    '10 Cashews',
    'Salt to taste',
    'Water as needed'
  ],
  instructions: [
    'Roast millet lightly',
    'Cook millet and moong dal together until soft',
    'Heat ghee and fry cashews, add cumin, pepper, and ginger',
    'Mix tempering with cooked millet and dal',
    'Serve hot'
  ],
  videoUrl: 'https://www.youtube.com/embed/t4EmZG-vpR8',
  chef: 'Traditional Recipe',
  tags: ['Healthy', 'Breakfast', 'South Indian']
},
301: {
  id: 301,
  name: 'Lemon Rice',
  image: 'https://www.spiceupthecurry.com/wp-content/uploads/2012/07/indian-lemon-rice-1.jpg',
  description: 'Tangy and aromatic South Indian rice flavored with lemon juice and spices',
  cookingTime: '15 minutes',
  prepTime: '5 minutes',
  servings: '4 people',
  calories: 180,
  difficulty: 'Easy',
  ingredients: [
    '2 cups Cooked rice',
    '2 tbsp Lemon juice',
    '1 tsp Mustard seeds',
    '1-2 Green chilies, chopped',
    '10-12 Curry leaves',
    '2 tbsp Oil',
    'Salt to taste',
    '1/4 tsp Turmeric powder',
    '2 tbsp Roasted peanuts (optional)'
  ],
  instructions: [
    'Heat oil in a pan and add mustard seeds',
    'Add green chilies, curry leaves, and turmeric, sauté for a minute',
    'Add cooked rice and mix well',
    'Turn off heat and add lemon juice, mix gently',
    'Garnish with roasted peanuts if using',
    'Serve warm'
  ],
  videoUrl: 'https://www.youtube.com/embed/Xt_ihBPaAm8',
  chef: 'Traditional Recipe',
  tags: ['Rice', 'Tangy', 'South Indian']
},

302: {
  id: 302,
  name: 'Curd Rice',
  image: 'https://www.indianhealthyrecipes.com/wp-content/uploads/2022/02/curd-rice-thayir-sadam.jpg',
  description: 'Soft, creamy South Indian rice mixed with yogurt and tempered with spices',
  cookingTime: '10 minutes',
  prepTime: '5 minutes',
  servings: '4 people',
  calories: 200,
  difficulty: 'Easy',
  ingredients: [
    '2 cups Cooked rice',
    '1 cup Yogurt',
    '1 tsp Mustard seeds',
    '1-2 Green chilies, chopped',
    '10 Curry leaves',
    '2 tbsp Oil',
    'Salt to taste',
    '1/4 tsp Grated ginger',
    '2 tbsp Coriander leaves, chopped'
  ],
  instructions: [
    'Mash the cooked rice slightly',
    'Mix rice with yogurt and salt',
    'Heat oil in a pan, add mustard seeds, green chilies, curry leaves, and ginger',
    'Pour the tempering over the rice',
    'Garnish with coriander leaves',
    'Serve chilled or at room temperature'
  ],
  videoUrl: 'https://www.youtube.com/embed/jzPWLcTMoTQ',
  chef: 'Traditional Recipe',
  tags: ['Rice', 'Yogurt', 'South Indian']
},

303: {
  id: 303,
  name: 'Tamarind Rice',
  image: 'https://smithakalluraya.com/wp-content/uploads/2020/03/puliyogare.jpg',
  description: 'Tangy and spicy South Indian rice flavored with tamarind paste and spices',
  cookingTime: '20 minutes',
  prepTime: '10 minutes',
  servings: '4 people',
  calories: 220,
  difficulty: 'Medium',
  ingredients: [
    '2 cups Cooked rice',
    '2 tbsp Tamarind paste',
    '1 tsp Mustard seeds',
    '1-2 Green chilies, chopped',
    '1/4 tsp Turmeric powder',
    '10-12 Curry leaves',
    '2 tbsp Oil',
    '1 tsp Chana dal',
    '1 tsp Urad dal',
    'Salt to taste',
    '2 tbsp Peanuts'
  ],
  instructions: [
    'Heat oil in a pan and fry chana dal, urad dal, and peanuts until golden',
    'Add mustard seeds, green chilies, curry leaves, and turmeric, sauté for a minute',
    'Add tamarind paste and a little water, cook for 2-3 minutes',
    'Mix in cooked rice and salt, stir gently',
    'Serve warm'
  ],
  videoUrl: 'https://www.youtube.com/embed/Zml50zZhRJY',
  chef: 'Traditional Recipe',
  tags: ['Rice', 'Tangy', 'South Indian']
},
401: {
  id: 401,
  name: 'Coconut Rice',
  image: 'https://www.gimmesomeoven.com/wp-content/uploads/2023/01/Coconut-Rice-Recipe-9-1100x1650.jpg',
  description: 'Fragrant South Indian rice cooked with grated coconut and tempered spices',
  cookingTime: '20 minutes',
  prepTime: '5 minutes',
  servings: '4 people',
  calories: 210,
  difficulty: 'Easy',
  ingredients: [
    '2 cups Cooked rice',
    '1/2 cup Grated coconut',
    '1 tsp Mustard seeds',
    '1-2 Green chilies, chopped',
    '10-12 Curry leaves',
    '2 tbsp Oil',
    'Salt to taste',
    '2 tbsp Cashews (optional)'
  ],
  instructions: [
    'Heat oil in a pan, add mustard seeds, green chilies, curry leaves, and cashews',
    'Add grated coconut and sauté for 2 minutes',
    'Mix in cooked rice and salt, stir gently',
    'Serve warm'
  ],
  videoUrl: 'https://www.youtube.com/embed/P_5p7jNbA7k',
  chef: 'Traditional Recipe',
  tags: ['Rice', 'Coconut', 'South Indian']
},

402: {
  id: 402,
  name: 'Tomato Rice',
  image: 'https://assets.bonappetit.com/photos/5f315fa5459e181dafb1c526/1:1/w_2560%2Cc_limit/HLY-FMC-Tomato-Rice-16x9.jpg',
  description: 'Spicy and tangy South Indian rice cooked with tomato puree and spices',
  cookingTime: '20 minutes',
  prepTime: '5 minutes',
  servings: '4 people',
  calories: 220,
  difficulty: 'Medium',
  ingredients: [
    '2 cups Cooked rice',
    '2 Medium tomatoes, pureed',
    '1 tsp Mustard seeds',
    '1-2 Green chilies, chopped',
    '10 Curry leaves',
    '1/4 tsp Turmeric powder',
    '2 tbsp Oil',
    '1 tsp Chana dal',
    '1 tsp Urad dal',
    'Salt to taste'
  ],
  instructions: [
    'Heat oil in a pan and fry chana dal and urad dal until golden',
    'Add mustard seeds, green chilies, curry leaves, and turmeric',
    'Add tomato puree and cook for 5-6 minutes until thick',
    'Mix in cooked rice and salt, stir gently',
    'Serve warm'
  ],
  videoUrl: 'https://www.youtube.com/embed/W4rvMmdMxwE',
  chef: 'Traditional Recipe',
  tags: ['Rice', 'Spicy', 'South Indian']
},

403: {
  id: 403,
  name: 'Curd Rice',
  image: 'https://www.indianhealthyrecipes.com/wp-content/uploads/2022/02/curd-rice-thayir-sadam.jpg',
  description: 'Soft, creamy South Indian rice mixed with yogurt and tempered with spices',
  cookingTime: '10 minutes',
  prepTime: '5 minutes',
  servings: '4 people',
  calories: 200,
  difficulty: 'Easy',
  ingredients: [
    '2 cups Cooked rice',
    '1 cup Yogurt',
    '1 tsp Mustard seeds',
    '1-2 Green chilies, chopped',
    '10 Curry leaves',
    '2 tbsp Oil',
    'Salt to taste',
    '1/4 tsp Grated ginger',
    '2 tbsp Coriander leaves, chopped'
  ],
  instructions: [
    'Mash the cooked rice slightly',
    'Mix rice with yogurt and salt',
    'Heat oil in a pan, add mustard seeds, green chilies, curry leaves, and ginger',
    'Pour the tempering over the rice',
    'Garnish with coriander leaves',
    'Serve chilled or at room temperature'
  ],
  videoUrl: 'https://www.youtube.com/embed/jzPWLcTMoTQ',
  chef: 'Traditional Recipe',
  tags: ['Rice', 'Yogurt', 'South Indian']
},

501: {
  id: 501,
  name: 'Ragi Koozh',
  image: 'https://farm4.staticflickr.com/3863/14769235856_69aa4728e2_c.jpg',
  description: 'Healthy porridge made from ragi (finger millet) flour, ideal for breakfast',
  cookingTime: '20 minutes',
  prepTime: '5 minutes',
  servings: '4 people',
  calories: 150,
  difficulty: 'Easy',
  ingredients: [
    '1 cup Ragi flour',
    '4 cups Water',
    'Salt to taste',
    'Jaggery or yogurt (optional)'
  ],
  instructions: [
    'Boil water and gradually add ragi flour, stirring continuously to avoid lumps',
    'Cook on low heat for 10-12 minutes until thick',
    'Add salt and mix well',
    'Serve warm with jaggery or yogurt if desired'
  ],
  videoUrl: 'https://www.youtube.com/embed/GaubB2mAjlU',
  chef: 'Traditional Recipe',
  tags: ['Millet', 'Healthy', 'Breakfast']
},

502: {
  id: 502,
  name: 'Ragi Dosa',
  image: 'https://www.kuchpakrahahai.in/wp-content/uploads/2020/10/Instant_Ragi_Dosa_1.jpg',
  description: 'Crispy and healthy dosa made with ragi flour',
  cookingTime: '20 minutes',
  prepTime: '6-8 hours (for fermentation)',
  servings: '4 people',
  calories: 160,
  difficulty: 'Medium',
  ingredients: [
    '1 cup Ragi flour',
    '1/4 cup Rice flour',
    '1/4 cup Urad dal (optional)',
    'Salt to taste',
    'Water as needed',
    'Oil for cooking'
  ],
  instructions: [
    'Mix ragi flour, rice flour, and urad dal (if using) with water to form a batter',
    'Ferment for 6-8 hours',
    'Heat a non-stick pan and pour a ladle of batter, spreading slightly',
    'Drizzle oil and cook until crispy',
    'Serve hot with chutney or sambar'
  ],
  videoUrl: 'https://www.youtube.com/embed/Lzv8BQHNF2E',
  chef: 'Traditional Recipe',
  tags: ['Millet', 'Crispy', 'South Indian']
},

503: {
  id: 503,
  name: 'Kambu Sadam',
  image: 'https://via.placeholder.com/600x400/a0522d/white?text=Kambu+Sadam',
  description: 'Nutritious pearl millet rice, a traditional South Indian dish',
  cookingTime: '25 minutes',
  prepTime: '5 minutes',
  servings: '4 people',
  calories: 200,
  difficulty: 'Easy',
  ingredients: [
    '1 cup Pearl millet (Kambu/Bajra)',
    '2 cups Water',
    'Salt to taste',
    '1 tsp Oil (optional)'
  ],
  instructions: [
    'Rinse millet and soak for 30 minutes',
    'Boil water and add millet with salt',
    'Cook on low heat until millet is soft and water is absorbed',
    'Fluff and serve warm'
  ],
  videoUrl: 'https://www.youtube.com/embed/b-Hhl2nk1rI',
  chef: 'Traditional Recipe',
  tags: ['Millet', 'Healthy', 'Rice']
},
601: {
  id: 601,
  name: 'Rava Dosa',
  image: 'https://www.kuchpakrahahai.in/wp-content/uploads/2020/10/Instant_Ragi_Dosa_1.jpg',
  description: 'Crispy South Indian crepe made from semolina, rice flour, and spices',
  cookingTime: '15 minutes',
  prepTime: '10 minutes',
  servings: '4 people',
  calories: 180,
  difficulty: 'Medium',
  ingredients: [
    '1 cup Semolina (Rava)',
    '1/4 cup Rice flour',
    '1/4 cup All-purpose flour',
    '2 Green chilies, chopped',
    '1-inch Ginger, grated',
    '10 Curry leaves, chopped',
    '1/4 tsp Cumin seeds',
    'Salt to taste',
    'Water as needed',
    'Oil for cooking'
  ],
  instructions: [
    'Mix semolina, rice flour, all-purpose flour, salt, and water to form a thin batter',
    'Add green chilies, ginger, cumin seeds, and curry leaves',
    'Heat a non-stick pan and pour batter in a thin circular motion',
    'Drizzle oil around edges and cook until golden and crispy',
    'Serve hot with chutney and sambar'
  ],
  videoUrl: 'https://www.youtube.com/embed/L1inYfbnSBA',
  chef: 'Traditional Recipe',
  tags: ['Breakfast', 'Crispy', 'South Indian']
},

602: {
  id: 602,
  name: 'Onion Uttapam',
  image: 'https://www.qualityfoodproducts.com/admin/upload/recipes/5e43ef2d3ca71.jpg',
  description: 'Thick South Indian pancake topped with chopped onions and spices',
  cookingTime: '15 minutes',
  prepTime: '8-10 hours (fermentation)',
  servings: '4 people',
  calories: 180,
  difficulty: 'Medium',
  ingredients: [
    '2 cups Dosa batter',
    '1 medium Onion, finely chopped',
    '1 Green chili, finely chopped',
    '1/4 cup Capsicum, finely chopped',
    'Fresh coriander leaves, chopped',
    'Salt to taste',
    'Oil for cooking'
  ],
  instructions: [
    'Prepare fermented dosa batter',
    'Heat a non-stick pan or tawa',
    'Pour a ladle of batter and spread slightly thick',
    'Sprinkle chopped onions, chili, capsicum, and coriander',
    'Drizzle oil around edges and cook until golden brown',
    'Serve hot with chutney and sambar'
  ],
  videoUrl: 'https://www.youtube.com/embed/MW3JZwjn8gY',
  chef: 'Traditional Recipe',
  tags: ['Breakfast', 'Vegetable', 'South Indian']
},

603: {
  id: 603,
  name: 'Ven Pongal',
  image: 'https://drishtidarshan.com/wp-content/uploads/2021/01/1-vn-pongal.jpg',
  description: 'Soft and savory South Indian rice and lentil porridge',
  cookingTime: '25 minutes',
  prepTime: '10 minutes',
  servings: '4 people',
  calories: 220,
  difficulty: 'Easy',
  ingredients: [
    '1 cup Rice',
    '1/4 cup Moong dal',
    '1 tsp Black peppercorns',
    '1 tsp Cumin seeds',
    '1-inch Ginger, grated',
    '10-12 Cashews',
    '2 tbsp Ghee',
    'Salt to taste',
    'Water as needed'
  ],
  instructions: [
    'Roast moong dal until fragrant',
    'Cook rice and moong dal together until soft',
    'In a pan, heat ghee and fry cashews until golden',
    'Add cumin, pepper, and ginger, sauté for a minute',
    'Mix tempering with cooked rice and dal',
    'Serve hot with coconut chutney or sambar'
  ],
  videoUrl: 'https://www.youtube.com/embed/GLSSQn4P8rg',
  chef: 'Traditional Recipe',
  tags: ['Breakfast', 'Soft', 'Savory']
},

701: {
  id: 701,
  name: 'Ragi Malt',
  image: 'https://www.theculinarypeace.com/wp-content/uploads/2020/06/Ragi-Malt-1474x2048.jpg',
  description: 'Nutritious and healthy ragi porridge, perfect for infants and adults',
  cookingTime: '15 minutes',
  prepTime: '5 minutes',
  servings: '2-3 people',
  calories: 120,
  difficulty: 'Easy',
  ingredients: [
    '1/4 cup Ragi flour',
    '1 cup Milk or water',
    '1-2 tsp Jaggery or sugar',
    '1/4 tsp Cardamom powder'
  ],
  instructions: [
    'Mix ragi flour with water to form a smooth paste',
    'Boil milk or water in a pan',
    'Add ragi paste slowly while stirring to avoid lumps',
    'Cook on low heat for 5-7 minutes until thick',
    'Add jaggery and cardamom powder, mix well',
    'Serve warm'
  ],
  videoUrl: 'https://www.youtube.com/embed/yLuUrexLWb0',
  chef: 'Traditional Recipe',
  tags: ['Millet', 'Healthy', 'Breakfast']
},

702: {
  id: 702,
  name: 'Ragi Dosa',
  image: 'https://farm5.staticflickr.com/4668/40112901962_ace304ac88_o.jpg',
  description: 'Crispy and healthy dosa made with ragi flour',
  cookingTime: '20 minutes',
  prepTime: '6-8 hours (fermentation)',
  servings: '4 people',
  calories: 160,
  difficulty: 'Medium',
  ingredients: [
    '1 cup Ragi flour',
    '1/4 cup Rice flour',
    '1/4 cup Urad dal (optional)',
    'Salt to taste',
    'Water as needed',
    'Oil for cooking'
  ],
  instructions: [
    'Mix ragi flour, rice flour, and urad dal (if using) with water to form a batter',
    'Ferment for 6-8 hours',
    'Heat a non-stick pan and pour a ladle of batter, spreading slightly',
    'Drizzle oil and cook until crispy',
    'Serve hot with chutney or sambar'
  ],
  videoUrl: 'https://www.youtube.com/embed/yLuUrexLWb0',
  chef: 'Traditional Recipe',
  tags: ['Millet', 'Crispy', 'South Indian']
},

703: {
  id: 703,
  name: 'Ragi Idli',
  image: 'https://www.secondrecipe.com/wp-content/uploads/2024/02/ragi-idli.jpg',
  description: 'Soft and healthy steamed cakes made from ragi and fermented batter',
  cookingTime: '15 minutes',
  prepTime: '6-8 hours (fermentation)',
  servings: '4 people',
  calories: 150,
  difficulty: 'Medium',
  ingredients: [
    '1 cup Ragi flour',
    '1/4 cup Urad dal',
    'Salt to taste',
    'Water as needed',
    'Oil for greasing idli molds'
  ],
  instructions: [
    'Soak urad dal for 4-6 hours and grind to smooth batter',
    'Mix urad dal batter with ragi flour and salt, adjust consistency with water',
    'Ferment for 6-8 hours',
    'Grease idli molds and pour batter',
    'Steam for 10-15 minutes until cooked',
    'Serve hot with chutney or sambar'
  ],
  videoUrl: 'https://www.youtube.com/embed/ejCj0E3diSU',
  chef: 'Traditional Recipe',
  tags: ['Millet', 'Steamed', 'Healthy']
},
801: {
  id: 801,
  name: 'Murukku',
  image: 'https://www.snacksbazzar.com/wp-content/uploads/2020/09/MURUKKU1.jpg',
  description: 'Crispy South Indian deep-fried snack made from rice flour and urad dal flour',
  cookingTime: '30 minutes',
  prepTime: '20 minutes',
  servings: '4 people',
  calories: 250,
  difficulty: 'Medium',
  ingredients: [
    '2 cups Rice flour',
    '1/2 cup Urad dal flour',
    '1 tsp Cumin seeds',
    '1/4 tsp Asafoetida',
    '1 tbsp Butter',
    'Salt to taste',
    'Water as needed',
    'Oil for deep frying'
  ],
  instructions: [
    'Mix rice flour, urad dal flour, cumin seeds, asafoetida, salt, and butter',
    'Add water gradually to form a soft dough',
    'Fill dough in a murukku press and shape into coils',
    'Heat oil and deep fry until golden and crispy',
    'Drain excess oil and cool before serving'
  ],
  videoUrl: 'https://www.youtube.com/embed/-3uqJUeDI2M',
  chef: 'Traditional Recipe',
  tags: ['Snack', 'Crispy', 'Festival']
},

802: {
  id: 802,
  name: 'Seedai',
  image: 'https://www.sharmispassions.com/wp-content/uploads/2022/08/uppu-seedai1.jpg',
  description: 'Crunchy deep-fried rice flour balls flavored with sesame and coconut',
  cookingTime: '25 minutes',
  prepTime: '15 minutes',
  servings: '4 people',
  calories: 200,
  difficulty: 'Medium',
  ingredients: [
    '1 cup Rice flour',
    '1/4 cup Grated coconut',
    '1 tsp Sesame seeds',
    '1 tbsp Butter',
    'Salt to taste',
    'Water as needed',
    'Oil for deep frying'
  ],
  instructions: [
    'Mix rice flour, coconut, sesame seeds, butter, and salt',
    'Add water gradually to form a soft dough',
    'Roll into small balls',
    'Heat oil and deep fry until golden and crisp',
    'Cool and store in an airtight container'
  ],
  videoUrl: 'https://www.youtube.com/embed/pFI2aFPSMsE',
  chef: 'Traditional Recipe',
  tags: ['Snack', 'Crispy', 'Festival']
},

803: {
  id: 803,
  name: 'Thattai',
  image: 'https://www.indianhealthyrecipes.com/wp-content/uploads/2019/10/thattai.jpg',
  description: 'Thin and crispy South Indian savory crackers made from rice flour',
  cookingTime: '20 minutes',
  prepTime: '15 minutes',
  servings: '4 people',
  calories: 220,
  difficulty: 'Medium',
  ingredients: [
    '2 cups Rice flour',
    '1/4 cup Chana dal flour',
    '1 tsp Cumin seeds',
    '1/4 tsp Red chili powder',
    '1 tbsp Butter',
    'Salt to taste',
    'Water as needed',
    'Oil for deep frying'
  ],
  instructions: [
    'Mix rice flour, chana dal flour, cumin, chili powder, butter, and salt',
    'Add water gradually to form a soft dough',
    'Roll out small discs or flatten by hand',
    'Heat oil and deep fry until golden and crispy',
    'Cool and store in an airtight container'
  ],
  videoUrl: 'https://www.youtube.com/embed/zBVcnyfRUq8',
  chef: 'Traditional Recipe',
  tags: ['Snack', 'Crispy', 'Festival']
},

901: {
  id: 901,
  name: 'Kothu Parotta',
  image: 'https://www.relishthebite.com/wp-content/uploads/2015/05/Kothuparotta9.jpg',
  description: 'Popular South Indian street food made by stir-frying shredded parotta with vegetables, eggs, or meat',
  cookingTime: '20 minutes',
  prepTime: '10 minutes',
  servings: '4 people',
  calories: 350,
  difficulty: 'Medium',
  ingredients: [
    '4 Parottas, shredded',
    '1 Onion, chopped',
    '2 Green chilies, chopped',
    '1 Tomato, chopped',
    '1/2 cup Mixed vegetables or meat',
    '2 Eggs (optional)',
    '2 tbsp Oil',
    'Salt and pepper to taste',
    'Curry leaves and coriander for garnish'
  ],
  instructions: [
    'Heat oil in a pan and sauté onions, chilies, tomatoes, and curry leaves',
    'Add vegetables or meat and cook until done',
    'Push ingredients to the side and scramble eggs if using',
    'Add shredded parotta and mix everything together',
    'Season with salt and pepper and garnish with coriander',
    'Serve hot'
  ],
  videoUrl: 'https://www.youtube.com/embed/ycshrU2DsqM',
  chef: 'Street Food',
  tags: ['Street Food', 'Spicy', 'South Indian']
},

902: {
  id: 902,
  name: 'Kari Dosa',
  image: 'https://i.ytimg.com/vi/5q2JnNhQyzs/maxresdefault.jpg',
  description: 'Spicy South Indian dosa served with meat or chicken curry',
  cookingTime: '25 minutes',
  prepTime: '8-10 hours (fermentation)',
  servings: '4 people',
  calories: 300,
  difficulty: 'Medium',
  ingredients: [
    '2 cups Dosa batter',
    '1 cup Chicken or mutton curry',
    'Oil for cooking',
    'Salt to taste'
  ],
  instructions: [
    'Prepare fermented dosa batter',
    'Heat a non-stick pan and pour batter to make a thin dosa',
    'Cook until golden brown and crispy',
    'Serve hot with spicy chicken or mutton curry'
  ],
  videoUrl: 'https://www.youtube.com/embed/5q2JnNhQyzs',
  chef: 'Traditional Recipe',
  tags: ['Breakfast', 'Spicy', 'South Indian']
},

903: {
  id: 903,
  name: 'Parotta with Salna',
  image: 'https://farm9.staticflickr.com/8628/16023206193_a6fd1310de_o.jpg',
  description: 'Flaky layered parotta served with spicy South Indian salna (curry)',
  cookingTime: '30 minutes',
  prepTime: '20 minutes',
  servings: '4 people',
  calories: 400,
  difficulty: 'Medium',
  ingredients: [
    '4 Parottas',
    '1 cup Salna or vegetable/meat curry',
    'Oil or ghee for serving'
  ],
  instructions: [
    'Heat parottas on a pan or tawa until warm and slightly crisp',
    'Heat salna separately',
    'Serve parotta with generous portion of salna on the side'
  ],
  videoUrl: 'https://www.youtube.com/embed/43AEhnPM5II',
  chef: 'Traditional Recipe',
  tags: ['Lunch/Dinner', 'Spicy', 'South Indian']
},
1001: {
  id: 1001,
  name: 'Vanilla Sponge Cake',
  image: 'https://www.keralacookingrecipes.com/wp-content/uploads/2019/01/vanilla-sponge-cake.jpg',
  description: 'Light and fluffy vanilla-flavored sponge cake, perfect for any occasion',
  cookingTime: '25 minutes',
  prepTime: '15 minutes',
  servings: '8 people',
  calories: 250,
  difficulty: 'Medium',
  ingredients: [
    '1 cup All-purpose flour',
    '1 cup Sugar',
    '4 Eggs',
    '1/2 cup Butter, melted',
    '1 tsp Vanilla extract',
    '1 tsp Baking powder',
    '1/4 cup Milk'
  ],
  instructions: [
    'Preheat oven to 180°C (350°F)',
    'Beat eggs and sugar until fluffy',
    'Add melted butter and vanilla extract, mix well',
    'Sift in flour and baking powder, fold gently',
    'Add milk gradually to get smooth batter',
    'Pour into greased cake pan and bake for 25 minutes',
    'Cool before serving'
  ],
  videoUrl: 'https://www.youtube.com/embed/FYjNz4xmLAk',
  chef: 'Traditional Recipe',
  tags: ['Dessert', 'Baking', 'Cake']
},

1002: {
  id: 1002,
  name: 'Chocolate Cake',
  image: 'https://www.valyastasteofhome.com/wp-content/uploads/2016/05/The-Best-Chocolate-Sponge-Cake-No-Oil-3.jpg',
  description: 'Rich and moist chocolate cake perfect for chocolate lovers',
  cookingTime: '30 minutes',
  prepTime: '15 minutes',
  servings: '8 people',
  calories: 300,
  difficulty: 'Medium',
  ingredients: [
    '1 cup All-purpose flour',
    '1 cup Sugar',
    '1/2 cup Cocoa powder',
    '1 tsp Baking powder',
    '1/2 cup Butter, melted',
    '2 Eggs',
    '1/2 cup Milk'
  ],
  instructions: [
    'Preheat oven to 180°C (350°F)',
    'Mix dry ingredients: flour, cocoa, sugar, and baking powder',
    'Add eggs, butter, and milk, mix until smooth',
    'Pour into greased pan and bake for 30 minutes',
    'Cool before serving'
  ],
  videoUrl: 'https://www.youtube.com/embed/GEctc8pOgRk',
  chef: 'Traditional Recipe',
  tags: ['Dessert', 'Chocolate', 'Cake']
},

1003: {
  id: 1003,
  name: 'Carrot Cake',
  image: 'https://www.modernhoney.com/wp-content/uploads/2019/04/The-Best-Carrot-Cake-Recipe9.jpg',
  description: 'Moist and flavorful cake made with grated carrots and warm spices',
  cookingTime: '35 minutes',
  prepTime: '15 minutes',
  servings: '8 people',
  calories: 280,
  difficulty: 'Medium',
  ingredients: [
    '1 1/2 cups All-purpose flour',
    '1 cup Sugar',
    '2 Eggs',
    '1/2 cup Vegetable oil',
    '1 tsp Baking powder',
    '1/2 tsp Baking soda',
    '1 tsp Cinnamon powder',
    '1 cup Grated carrots',
    '1/4 cup Chopped walnuts (optional)'
  ],
  instructions: [
    'Preheat oven to 180°C (350°F)',
    'Mix flour, baking powder, baking soda, cinnamon, and sugar',
    'Add eggs and oil, mix well',
    'Fold in grated carrots and walnuts',
    'Pour batter into greased pan and bake for 35 minutes',
    'Cool before serving'
  ],
  videoUrl: 'https://www.youtube.com/embed/T8cVvEzZEp0',
  chef: 'Traditional Recipe',
  tags: ['Dessert', 'Cake', 'Vegetable']
},

1101: {
  id: 1101,
  name: 'Spaghetti Aglio e Olio',
  image: 'https://essenrezept.de/wp-content/uploads/2021/03/Spaghetti-aglio-e-olio-2-1527x2048.jpg',
  description: 'Classic Italian pasta dish made with garlic, olive oil, and chili flakes',
  cookingTime: '15 minutes',
  prepTime: '5 minutes',
  servings: '2 people',
  calories: 350,
  difficulty: 'Easy',
  ingredients: [
    '200g Spaghetti',
    '3 Garlic cloves, sliced',
    '3 tbsp Olive oil',
    '1/2 tsp Red chili flakes',
    'Salt to taste',
    'Fresh parsley, chopped',
    'Grated Parmesan (optional)'
  ],
  instructions: [
    'Cook spaghetti in salted boiling water until al dente',
    'Heat olive oil in a pan, add garlic and chili flakes, sauté until golden',
    'Add cooked spaghetti to the pan, toss well',
    'Season with salt and garnish with parsley and Parmesan',
    'Serve hot'
  ],
  videoUrl: 'https://www.youtube.com/embed/UmTqq_o6FSI',
  chef: 'Italian Recipe',
  tags: ['Pasta', 'Italian', 'Quick']
},

1102: {
  id: 1102,
  name: 'Margherita Pizza',
  image: 'https://www.inspiredtaste.net/wp-content/uploads/2023/09/Margherita-Pizza-5-1200.jpg',
  description: 'Classic Italian pizza with tomato, mozzarella, and fresh basil',
  cookingTime: '20 minutes',
  prepTime: '1 hour (including dough resting)',
  servings: '4 people',
  calories: 400,
  difficulty: 'Medium',
  ingredients: [
    '1 Pizza base',
    '1/2 cup Tomato sauce',
    '1 cup Mozzarella cheese, grated',
    'Fresh basil leaves',
    'Olive oil',
    'Salt to taste'
  ],
  instructions: [
    'Preheat oven to 220°C (430°F)',
    'Spread tomato sauce over the pizza base',
    'Sprinkle grated mozzarella and place basil leaves',
    'Drizzle olive oil and bake for 15-20 minutes until cheese melts and crust is golden',
    'Serve hot'
  ],
  videoUrl: 'https://www.youtube.com/embed/vcfNpDtVqOw',
  chef: 'Italian Recipe',
  tags: ['Pizza', 'Italian', 'Vegetarian']
},

1103: {
  id: 1103,
  name: 'Lasagna',
  image: 'https://www.recetasdesbieta.com/wp-content/uploads/2018/10/lasagna-original..jpg',
  description: 'Layered Italian pasta dish with meat, cheese, and tomato sauce',
  cookingTime: '45 minutes',
  prepTime: '20 minutes',
  servings: '6 people',
  calories: 450,
  difficulty: 'Medium',
  ingredients: [
    '9 Lasagna sheets',
    '2 cups Tomato sauce',
    '1 cup Ricotta cheese',
    '1 cup Mozzarella cheese, grated',
    '1/2 lb Ground beef or vegetables',
    '1 Onion, chopped',
    '2 Garlic cloves, minced',
    'Salt and pepper to taste',
    'Olive oil'
  ],
  instructions: [
    'Preheat oven to 180°C (350°F)',
    'Cook lasagna sheets according to package instructions',
    'Sauté onion, garlic, and ground beef until cooked, add tomato sauce',
    'In a baking dish, layer lasagna sheets, ricotta, meat sauce, and mozzarella',
    'Repeat layers and top with mozzarella',
    'Bake for 30-35 minutes until cheese is golden',
    'Serve hot'
  ],
  videoUrl: 'https://www.youtube.com/embed/fVDsTP-pTXs',
  chef: 'Italian Recipe',
  tags: ['Pasta', 'Italian', 'Baked']
},
    // Add more detailed recipes as needed
  };

  useEffect(() => {
    const recipeDetails = recipeData[recipeId];
    if (recipeDetails) {
      setRecipe(recipeDetails);
    }

    // Check if recipe is in favorites
    const favorites = JSON.parse(localStorage.getItem('favorites') || '[]');
    setIsFavorite(favorites.includes(parseInt(recipeId)));
  }, [recipeId]);

  const toggleFavorite = () => {
    const favorites = JSON.parse(localStorage.getItem('favorites') || '[]');
    const recipeIdNum = parseInt(recipeId);

    const newFavorites = isFavorite
      ? favorites.filter(id => id !== recipeIdNum)
      : [...favorites, recipeIdNum];

    localStorage.setItem('favorites', JSON.stringify(newFavorites));
    setIsFavorite(!isFavorite);
  };

  if (!recipe) {
    return (
      <div className="loading">
        <div className="spinner"></div>
      </div>
    );
  }

  return (
    <div className="recipe-details">
      <div style={{ textAlign: 'center', marginBottom: '30px' }}>
         <img 
  src="/image.png" 
  alt="Moushi Cookbook Logo" 
  className="recipe-logo"
  style={{ width: '60px', height: '60px', margin: '0 auto 15px' }}
  onError={(e) => {
    e.target.onerror = null; // prevent infinite loop
    e.target.src = '/images/photo.png'; // fallback if missing
  }}
        />
        <h1 style={{ fontSize: '32px', color: '#333', marginBottom: '10px' }}>
          {recipe.name}
        </h1>
        <p style={{ color: '#666', fontSize: '16px', maxWidth: '600px', margin: '0 auto' }}>
          {recipe.description}
        </p>
      </div>

      <div style={{ textAlign: 'center', marginBottom: '30px' }}>

          <img
  src={recipe.image}
  alt={recipe.name}
  style={{
    width: '100%',
    maxWidth: '600px',
    height: '400px',
    objectFit: 'cover',
    borderRadius: '15px',
    boxShadow: '0 10px 30px rgba(0,0,0,0.1)'
  }}
  onError={(e) => {
    e.target.src = '/images/photo.jpg'; // Local fallback image
  }}
        />
      </div>

      <div style={{ 
        display: 'grid', 
        gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))', 
        gap: '20px', 
        marginBottom: '30px',
        padding: '20px',
        background: 'white',
        borderRadius: '15px',
        boxShadow: '0 4px 15px rgba(0,0,0,0.1)'
      }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{ color: '#ff6b6b', fontWeight: 'bold', fontSize: '18px' }}>
            {recipe.cookingTime}
          </div>
          <div style={{ color: '#666', fontSize: '14px' }}>{t('cookingTime')}</div>
        </div>
        <div style={{ textAlign: 'center' }}>
          <div style={{ color: '#ff6b6b', fontWeight: 'bold', fontSize: '18px' }}>
            {recipe.calories}
          </div>
          <div style={{ color: '#666', fontSize: '14px' }}>{t('calories')}</div>
        </div>
        <div style={{ textAlign: 'center' }}>
          <div style={{ color: '#ff6b6b', fontWeight: 'bold', fontSize: '18px' }}>
            {recipe.servings}
          </div>
          <div style={{ color: '#666', fontSize: '14px' }}>Servings</div>
        </div>
        <div style={{ textAlign: 'center' }}>
          <button
            onClick={toggleFavorite}
            style={{
              background: isFavorite ? '#ff6b6b' : '#f0f0f0',
              color: isFavorite ? 'white' : '#333',
              border: 'none',
              padding: '10px 20px',
              borderRadius: '20px',
              cursor: 'pointer',
              fontWeight: 'bold'
            }}
          >
            {isFavorite ? '❤️ Favorited' : '🤍 Add to Favorites'}
          </button>
        </div>
      </div>

      {/* YouTube Video */}
      <div className="video-container">
        <iframe
          className="video-player"
          src={recipe.videoUrl}
          title={`${recipe.name} Recipe Video`}
          frameBorder="0"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
        ></iframe>
      </div>

      {/* Ingredients Section */}
      <div className="ingredients-section">
        <h3>{t('ingredients')}</h3>
        <div className="ingredients-list">
          {recipe.ingredients.map((ingredient, index) => (
            <div key={index} className="ingredient-item">
              {ingredient}
            </div>
          ))}
        </div>
      </div>

      {/* Instructions Section */}
      <div className="instructions-section">
        <h3>{t('instructions')}</h3>
        <div className="instructions-list">
          {recipe.instructions.map((instruction, index) => (
            <div key={index} className="instruction-step">
              {instruction}
            </div>
          ))}
        </div>
      </div>

      {/* Recipe Tags */}
      <div style={{ 
        display: 'flex', 
        flexWrap: 'wrap', 
        gap: '10px', 
        justifyContent: 'center', 
        marginTop: '30px' 
      }}>
        {recipe.tags?.map((tag, index) => (
          <span
            key={index}
            style={{
              background: '#ff6b6b',
              color: 'white',
              padding: '5px 15px',
              borderRadius: '20px',
              fontSize: '14px',
              fontWeight: '500'
            }}
          >
            {tag}
          </span>
        ))}
      </div>
    </div>
  );
};

export default RecipePage;