import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext';

const ClassesPage = () => {
  const { t } = useLanguage();
  const [enrolledClasses, setEnrolledClasses] = useState([]);

  const cookingClasses = [
    {
      id: 'c1',
      title: 'Basic Tamil Cooking',
      level: 'beginnerLevel',
      duration: '4 weeks',
      price: '₹2,500',
      image: 'https://static.vecteezy.com/system/resources/previews/007/956/808/large_2x/cooking-class-logo-food-logo-template-free-vector.jpg',
      description: 'Learn the fundamentals of Tamil cooking including rice preparations, sambar, and rasam',
      topics: ['Rice cooking techniques', 'Basic sambar', 'Simple rasam', 'Vegetable preparations'],
      instructor: 'Chef Meera Krishnan',
      rating: 4.8,
      students: 245
    },
    {
      id: 'c2',
      title: 'Traditional Breakfast Items',
      level: 'beginnerLevel',
      duration: '3 weeks',
      price: '₹2,000',
      image: 'https://www.tastingtable.com/img/gallery/15-indian-breakfasts-you-need-to-try-at-least-once/intro-1671483071.jpg',
      description: 'Master the art of making perfect idli, dosa, vada, and other breakfast staples',
      topics: ['Idli and dosa batter', 'Perfect dosa technique', 'Medu vada', 'Chutneys and sambar'],
      instructor: 'Chef Rajesh Kumar',
      rating: 4.9,
      students: 189
    },
    {
      id: 'c3',
      title: 'Chettinad Cuisine Mastery',
      level: 'intermediateLevel',
      duration: '6 weeks',
      price: '₹4,500',
      image: 'https://assets.cntraveller.in/photos/60ba17670f3a5367ec9fe1cf/master/pass/NV-Horizontal-Thali-Shot1-jpg.jpg',
      description: 'Dive deep into the spicy and flavorful world of Chettinad cooking',
      topics: ['Chettinad masala preparation', 'Chicken Chettinad', 'Fish curry', 'Traditional kuzhambu'],
      instructor: 'Chef Soundararajan',
      rating: 4.7,
      students: 156
    },
    {
      id: 'c4',
      title: 'Street Food Specialties',
      level: 'intermediateLevel',
      duration: '4 weeks',
      price: '₹3,200',
      image: 'https://i.ytimg.com/vi/WxKnGVWfsE4/maxresdefault.jpg',
      description: 'Learn to make popular Tamil street foods like kothu parotta, sundal varieties',
      topics: ['Kothu parotta mastery', 'Various sundal types', 'Bajji varieties', 'Chaat preparations'],
      instructor: 'Chef Murugan',
      rating: 4.6,
      students: 203
    },
    {
      id: 'c5',
      title: 'Festival Cooking & Sweets',
      level: 'advancedLevel',
      duration: '8 weeks',
      price: '₹6,000',
      image: 'https://img.freepik.com/premium-photo/white-truffle-festival-cooking-class_1186551-41650.jpg',
      description: 'Master traditional festival foods and authentic Tamil sweets',
      topics: ['Traditional payasam', 'Festival specials', 'Sweet making techniques', 'Prasadam preparation'],
      instructor: 'Chef Lakshmi Devi',
      rating: 4.9,
      students: 98
    },
    {
      id: 'c6',
      title: 'Restaurant-Style Cooking',
      level: 'advancedLevel',
      duration: '10 weeks',
      price: '₹8,500',
      image: 'https://st.focusedcollection.com/18590116/i/1800/focused_224833498-stock-photo-head-chef-teaching-his-team.jpg',
      description: 'Learn professional techniques and restaurant-quality Tamil dishes',
      topics: ['Bulk cooking methods', 'Consistency techniques', 'Professional presentation', 'Business recipes'],
      instructor: 'Chef Venkatesh Bhat',
      rating: 4.8,
      students: 67
    }
  ];

  const bakingClasses = [
    {
      id: 'b1',
      title: 'Basic Baking Fundamentals',
      level: 'beginnerLevel',
      duration: '4 weeks',
      price: '₹3,500',
      image: 'https://rtholdings.edu.vn/wp-content/uploads/2023/05/DSC00020-min.jpg',
      description: 'Learn baking basics with Tamil fusion elements',
      topics: ['Basic cake making', 'Cookie techniques', 'Bread basics', 'Tamil-inspired flavors'],
      instructor: 'Chef Priya Raman',
      rating: 4.7,
      students: 134
    },
    {
      id: 'b2',
      title: 'Cake Decoration & Design',
      level: 'intermediateLevel',
      duration: '5 weeks',
      price: '₹4,200',
      image: 'https://i.pinimg.com/originals/57/26/02/572602254b6fa24d8aad5aa482d0c51a.jpg',
      description: 'Advanced cake decoration with traditional motifs',
      topics: ['Buttercream techniques', 'Fondant work', 'Traditional designs', 'Color theory'],
      instructor: 'Chef Anitha Suresh',
      rating: 4.8,
      students: 89
    },
    {
      id: 'b3',
      title: 'Artisan Bread Making',
      level: 'advancedLevel',
      duration: '6 weeks',
      price: '₹5,500',
      image: 'https://italycookingschools.com/wp-content/uploads/2023/05/Best-Bread-making-Classes-in-London-Feature-Image.jpg',
      description: 'Master artisan bread techniques with local ingredients',
      topics: ['Sourdough starters', 'Fermentation science', 'Shaping techniques', 'Traditional flavors'],
      instructor: 'Chef David Raj',
      rating: 4.9,
      students: 45
    }
  ];

  const enrollInClass = (classId) => {
    if (!enrolledClasses.includes(classId)) {
      setEnrolledClasses([...enrolledClasses, classId]);
    }
  };

  const getLevelColor = (level) => {
    switch (level) {
      case 'beginnerLevel': return '#90ee90';
      case 'intermediateLevel': return '#ffa500';
      case 'advancedLevel': return '#ff6b6b';
      default: return '#ccc';
    }
  };

  const renderClassCard = (classItem, category) => (
    <div key={classItem.id} className="product-card" style={{ height: 'auto' }}>
        <img
  src={classItem.image}
  alt={classItem.name}
  className="product-image"
  style={{
    width: '100%',
    maxWidth: '600px',
    height: '400px',
    objectFit: 'cover',
    borderRadius: '15px',
    boxShadow: '0 10px 30px rgba(0,0,0,0.1)'
  }}
  onError={(e) => {
    e.target.src = '/images/photo.jpg'; // Local fallback image
  }}
      />
      <div className="product-info">
        <div style={{ 
          display: 'flex', 
          justifyContent: 'space-between', 
          alignItems: 'center',
          marginBottom: '8px'
        }}>
          <span style={{
            background: getLevelColor(classItem.level),
            color: 'white',
            padding: '4px 8px',
            borderRadius: '12px',
            fontSize: '12px',
            fontWeight: '600'
          }}>
            {t(classItem.level)}
          </span>
          <span style={{ color: '#666', fontSize: '14px' }}>
            ⭐ {classItem.rating} ({classItem.students})
          </span>
        </div>

        <h4 style={{ margin: '8px 0', fontSize: '16px' }}>{classItem.title}</h4>

        <p style={{ 
          fontSize: '14px', 
          color: '#666', 
          margin: '8px 0',
          lineHeight: '1.4'
        }}>
          {classItem.description}
        </p>

        <div style={{ margin: '10px 0' }}>
          <div style={{ fontSize: '12px', color: '#999', marginBottom: '5px' }}>
            Instructor: {classItem.instructor}
          </div>
          <div style={{ fontSize: '12px', color: '#999', marginBottom: '5px' }}>
            Duration: {classItem.duration}
          </div>
        </div>

        <div style={{ margin: '10px 0' }}>
          <strong style={{ fontSize: '14px', color: '#333' }}>Topics covered:</strong>
          <ul style={{ 
            fontSize: '12px', 
            color: '#666', 
            margin: '5px 0 10px 15px',
            lineHeight: '1.3'
          }}>
            {classItem.topics.slice(0, 3).map((topic, index) => (
              <li key={index}>{topic}</li>
            ))}
            {classItem.topics.length > 3 && (
              <li>...and more</li>
            )}
          </ul>
        </div>

        <div className="product-price" style={{ marginBottom: '15px' }}>
          {classItem.price}
        </div>

        <button
          className="add-to-cart"
          onClick={() => enrollInClass(classItem.id)}
          disabled={enrolledClasses.includes(classItem.id)}
          style={{ width: '100%' }}
        >
          {enrolledClasses.includes(classItem.id) ? 'Enrolled ✓' : 'Enroll Now'}
        </button>
      </div>
    </div>
  );

  return (
    <div className="home-container">
      <div style={{ textAlign: 'center', marginBottom: '40px' }}>
         <img 
  src="/image.png" 
  alt="Moushi Cookbook Logo" 
  className="logo"
  style={{ width: '60px', height: '60px', margin: '0 auto 15px' }}
  onError={(e) => {
    e.target.onerror = null; // prevent infinite loop
    e.target.src = '/images/photo.png'; // fallback if missing
  }}
        />
        <h2 style={{ fontSize: '28px', color: '#333', marginBottom: '10px' }}>
          {t('classes')}
        </h2>
        <p style={{ color: '#666', fontSize: '16px' }}>
          Learn authentic Tamil cooking and baking from expert chefs
        </p>
      </div>

      {/* Level Legend */}
      <div style={{ 
        display: 'flex', 
        justifyContent: 'center', 
        gap: '20px', 
        marginBottom: '30px',
        flexWrap: 'wrap'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <span style={{ 
            width: '16px', 
            height: '16px', 
            background: '#90ee90', 
            borderRadius: '50%' 
          }}></span>
          <span style={{ fontSize: '14px' }}>{t('beginnerLevel')}</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <span style={{ 
            width: '16px', 
            height: '16px', 
            background: '#ffa500', 
            borderRadius: '50%' 
          }}></span>
          <span style={{ fontSize: '14px' }}>{t('intermediateLevel')}</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <span style={{ 
            width: '16px', 
            height: '16px', 
            background: '#ff6b6b', 
            borderRadius: '50%' 
          }}></span>
          <span style={{ fontSize: '14px' }}>{t('advancedLevel')}</span>
        </div>
      </div>

      {/* Cooking Classes Section */}
      <div style={{ marginBottom: '50px' }}>
        <h3 style={{ 
          fontSize: '24px', 
          color: '#333', 
          marginBottom: '25px',
          textAlign: 'center'
        }}>
          {t('cookingClasses')}
        </h3>
        <div className="products-grid">
          {cookingClasses.map(classItem => renderClassCard(classItem, 'cooking'))}
        </div>
      </div>

      {/* Baking Classes Section */}
      <div>
        <h3 style={{ 
          fontSize: '24px', 
          color: '#333', 
          marginBottom: '25px',
          textAlign: 'center'
        }}>
          {t('bakingClasses')}
        </h3>
        <div className="products-grid">
          {bakingClasses.map(classItem => renderClassCard(classItem, 'baking'))}
        </div>
      </div>\
      {/* Enrollment Summary */}
      {enrolledClasses.length > 0 && (
        <div style={{ 
          position: 'fixed', 
          bottom: '20px', 
          right: '20px', 
          background: 'white', 
          padding: '15px', 
          borderRadius: '10px',
          boxShadow: '0 5px 20px rgba(0,0,0,0.2)',
          zIndex: 1000
        }}>
          📚 Enrolled Classes: {enrolledClasses.length}
        </div>
      )}
    </div>
  );
};

export default ClassesPage;