import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext';

const ProductsPage = () => {
  const { t } = useLanguage();
  const [activeCategory, setActiveCategory] = useState('groceries');
  const [cart, setCart] = useState([]);
  const [wishlist, setWishlist] = useState([]);

  const productCategories = {
    groceries: {
      name: t('groceries'),
      products: [
        {
          id: 'g1',
          name: 'Sona Masoori Rice',
          category: 'Grains & Millets',
          price: '₹85',
          image: 'https://d2j6dbq0eux0bg.cloudfront.net/images/20181022/1701525296.jpg',
          description: 'Premium quality Sona Masoori rice - 1kg'
        },
        {
          id: 'g2',
          name: 'Idli Rice',
          category: 'Grains & Millets',
          price: '₹95',
          image: 'https://5.imimg.com/data5/SELLER/Default/2021/12/PX/PG/QP/143714853/25kg-special-idli-rice-1000x1000.jpg',
          description: 'Special idli rice for perfect idlis - 1kg'
        },
        {
          id: 'g3',
          name: 'Toor Dal',
          category: 'Pulses & Lentils',
          price: '₹120',
          image: 'https://www.dwarakaorganic.com/wp-content/uploads/2012/06/Toor-Dal-Recipe.jpg',
          description: 'Premium Toor dal (Thuvaram paruppu) - 1kg'
        },
        {
          id: 'g4',
          name: 'Urad Dal',
          category: 'Pulses & Lentils',
          price: '₹140',
          image: 'https://www.sailusfood.com/wp-content/uploads/2016/01/urad-dal-white-lentils.jpg',
          description: 'Whole Urad dal for vada and dosa - 1kg'
        },
        {
          id: 'g5',
          name: 'Curry Leaves',
          category: 'Vegetables & Greens',
          price: '₹25',
          image: 'https://www.1mg.com/articles/wp-content/uploads/2016/10/curry-leaves.jpg',
          description: 'Fresh curry leaves - 100g'
        },
        {
          id: 'g6',
          name: 'Coconut Oil',
          category: 'Oils & Fats',
          price: '₹180',
          image: 'https://wallpapercave.com/wp/wp9192632.jpg',
          description: 'Cold-pressed coconut oil - 500ml'
        },
        {
          id: 'g7',
          name: 'Sambar Powder',
          category: 'Spices & Masalas',
          price: '₹75',
          image: 'https://www.sharmispassions.com/wp-content/uploads/2022/02/SambarPowder4.jpg',
          description: 'Authentic sambar powder - 200g'
        },
        {
          id: 'g8',
          name: 'Jaggery (Vellam)',
          category: 'Sweeteners',
          price: '₹65',
          image: 'https://wallpaperaccess.com/full/7923705.jpg',
          description: 'Pure jaggery blocks - 500g'
        }
      ]
    },
    kitchenGadgets: {
      name: t('kitchenGadgets'),
      products: [
        {
          id: 'k1',
          name: 'Pressure Cooker',
          category: 'Cooking Basics',
          price: '₹2,500',
          image: 'https://m.media-amazon.com/images/I/51+5yrJBTnL._SL1000_.jpg',
          description: '5L stainless steel pressure cooker'
        },
        {
          id: 'k2',
          name: 'Cast Iron Tawa',
          category: 'Cooking Basics',
          price: '₹850',
          image: 'https://wskart.in/wp-content/uploads/2022/01/Wskart-Solimo-Pre-Seasoned-Cast-Iron-Dosa-Tawa.jpg',
          description: 'Traditional cast iron dosa tawa'
        },
        {
          id: 'k3',
          name: 'Idli Cooker',
          category: 'Cooking Basics',
          price: '₹450',
          image: 'https://images-na.ssl-images-amazon.com/images/I/611lcgpTRqL._SL1500_.jpg',
          description: '4-plate stainless steel idli cooker'
        },
        {
          id: 'k4',
          name: 'Wet Grinder',
          category: 'Grinding & Blending',
          price: '₹4,500',
          image: 'https://ramaappliances.in/wp-content/uploads/2021/05/Rama-Wetgrinders.jpg',
          description: 'Table top wet grinder for batter'
        },
        {
          id: 'k5',
          name: 'Coconut Scraper',
          category: 'Cutting & Prep',
          price: '₹350',
          image: 'https://5.imimg.com/data5/SELLER/Default/2024/1/377654180/IK/GN/PL/64023267/coconut-scrapers-machine-manual-steel-for-home-kitchen-use-5216-1000x1000.jpg',
          description: 'Traditional coconut scraper (Thengai thuruvai)'
        },
        {
          id: 'k6',
          name: 'Mortar & Pestle',
          category: 'Grinding & Blending',
          price: '₹750',
          image: 'https://morningchores.com/wp-content/uploads/2021/02/ChefSofi-Mortar-and-Pestle-Set.jpg',
          description: 'Granite mortar & pestle (Aatukal/Ammi kal)'
        },
        {
          id: 'k7',
          name: 'Filter Coffee Maker',
          category: 'Beverages & Extras',
          price: '₹1,200',
          image: 'https://images-na.ssl-images-amazon.com/images/I/31v%2BW9zBGWL.jpg',
          description: 'Traditional South Indian filter coffee maker'
        },
        {
          id: 'k8',
          name: 'Spice Box (Masala Dabba)',
          category: 'Mixing & Storage',
          price: '₹650',
          image: 'https://m.media-amazon.com/images/I/61by7rgySNL.jpg',
          description: 'Stainless steel masala dabba with 7 compartments'
        }
      ]
    }
  };

  const addToCart = (productId) => {
    if (!cart.includes(productId)) {
      setCart([...cart, productId]);
    }
  };

  const addToWishlist = (productId) => {
    if (wishlist.includes(productId)) {
      setWishlist(wishlist.filter(id => id !== productId));
    } else {
      setWishlist([...wishlist, productId]);
    }
  };

  const currentProducts = productCategories[activeCategory]?.products || [];

  return (
    <div className="home-container">
      <div style={{ textAlign: 'center', marginBottom: '30px' }}>
         <img 
  src="/image.png" 
  alt="Moushi Cookbook Logo" 
  className="logo"
  style={{ width: '60px', height: '60px', margin: '0 auto 15px' }}
  onError={(e) => {
    e.target.onerror = null; // prevent infinite loop
    e.target.src = '/images/photo.png'; // fallback if missing
  }}
        />
        <h2 style={{ fontSize: '28px', color: '#333', marginBottom: '10px' }}>
          {t('products')}
        </h2>
        <p style={{ color: '#666', fontSize: '16px' }}>
          Everything you need for authentic Tamil cooking
        </p>
      </div>

      {/* Category Tabs */}
      <div style={{ 
        display: 'flex', 
        justifyContent: 'center', 
        marginBottom: '30px',
        gap: '20px',
        flexWrap: 'wrap'
      }}>
        {Object.entries(productCategories).map(([key, category]) => (
          <button
            key={key}
            onClick={() => setActiveCategory(key)}
            style={{
              padding: '12px 24px',
              border: 'none',
              borderRadius: '25px',
              background: activeCategory === key ? '#ff6b6b' : '#f0f0f0',
              color: activeCategory === key ? 'white' : '#333',
              fontWeight: '600',
              cursor: 'pointer',
              fontSize: '16px',
              transition: 'all 0.3s'
            }}
          >
            {category.name}
          </button>
        ))}
      </div>

      {/* Products Grid */}
      <div className="products-grid">
        {currentProducts.map((product) => (
          <div key={product.id} className="product-card">
               <img
  src={product.image}
  alt={product.name}
  style={{
    width: '100%',
    maxWidth: '600px',
    height: '400px',
    objectFit: 'cover',
    borderRadius: '15px',
    boxShadow: '0 10px 30px rgba(0,0,0,0.1)'
  }}
  onError={(e) => {
    e.target.src = '/images/photo.jpg'; // Local fallback image
  }}
            />
            <div className="product-info">
              <div style={{ fontSize: '12px', color: '#999', marginBottom: '5px' }}>
                {product.category}
              </div>
              <h4>{product.name}</h4>
              <p style={{ fontSize: '14px', color: '#666', margin: '8px 0' }}>
                {product.description}
              </p>
              <div className="product-price">{product.price}</div>
              <div className="product-actions">
                <button
                  className="add-to-cart"
                  onClick={() => addToCart(product.id)}
                  disabled={cart.includes(product.id)}
                >
                  {cart.includes(product.id) ? 'In Cart' : t('addToCart')}
                </button>
                <button
                  className="add-to-wishlist"
                  onClick={() => addToWishlist(product.id)}
                  style={{
                    background: wishlist.includes(product.id) ? '#ff6b6b' : '#f0f0f0',
                    color: wishlist.includes(product.id) ? 'white' : '#333'
                  }}
                >
                  {wishlist.includes(product.id) ? '❤️' : t('addToWishlist')}
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Cart and Wishlist Summary */}
      {(cart.length > 0 || wishlist.length > 0) && (
        <div style={{ 
          position: 'fixed', 
          bottom: '20px', 
          right: '20px', 
          background: 'white', 
          padding: '15px', 
          borderRadius: '10px',
          boxShadow: '0 5px 20px rgba(0,0,0,0.2)',
          zIndex: 1000
        }}>
          {cart.length > 0 && (
            <div style={{ marginBottom: '10px' }}>
              🛒 Cart: {cart.length} items
            </div>
          )}
          {wishlist.length > 0 && (
            <div>
              ❤️ Wishlist: {wishlist.length} items
            </div>
          )}
        </div>
      )}

      {/* Payment Options Info */}
      <div style={{ 
        marginTop: '40px', 
        padding: '20px', 
        background: 'white', 
        borderRadius: '15px',
        boxShadow: '0 4px 15px rgba(0,0,0,0.1)',
        textAlign: 'center'
      }}>
        <h3 style={{ color: '#ff6b6b', marginBottom: '15px' }}>Payment Options</h3>
        <div style={{ display: 'flex', justifyContent: 'center', gap: '20px', flexWrap: 'wrap' }}>
          <span style={{ padding: '8px 16px', background: '#f0f0f0', borderRadius: '20px' }}>💳 Credit Card</span>
          <span style={{ padding: '8px 16px', background: '#f0f0f0', borderRadius: '20px' }}>💰 UPI</span>
          <span style={{ padding: '8px 16px', background: '#f0f0f0', borderRadius: '20px' }}>🏦 Net Banking</span>
          <span style={{ padding: '8px 16px', background: '#f0f0f0', borderRadius: '20px' }}>💵 Cash on Delivery</span>
        </div>
      </div>
    </div>
  );
};

export default ProductsPage;