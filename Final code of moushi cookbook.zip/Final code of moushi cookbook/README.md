# Moushi Cookbook - Tamil Recipe Website

A comprehensive React.js website featuring authentic Tamil recipes, cooking classes, and kitchen products.

## Features

- **Multi-language Support**: English, Tamil, and Hindi
- **Recipe Categories**: 13+ categories including Popular, Trending, Chef Signature, Street Food, etc.
- **User Authentication**: Login system with email/password
- **Search Functionality**: Search recipes by name or category
- **Product Store**: Groceries and kitchen gadgets with cart/wishlist
- **Cooking Classes**: Beginner to advanced level classes
- **Responsive Design**: Mobile-friendly interface
- **Video Integration**: YouTube recipe videos

## Installation

1. Make sure you have Node.js installed (version 14 or higher)

2. Install dependencies:
```bash
npm install
```

3. Start the development server:
```bash
npm start
```

4. Open your browser and navigate to `http://localhost:3000`

## Project Structure

```
moushi-cookbook/
├── public/
│   ├── index.html
│   └── manifest.json
├── src/
│   ├── components/
│   │   ├── LoginPage.js
│   │   ├── HomePage.js
│   │   ├── Header.js
│   │   ├── CategoryPage.js
│   │   ├── RecipePage.js
│   │   ├── ProductsPage.js
│   │   ├── ClassesPage.js
│   │   ├── SearchPage.js
│   │   └── Footer.js
│   ├── context/
│   │   └── LanguageContext.js
│   ├── App.js
│   ├── App.css
│   ├── index.js
│   └── index.css
├── package.json
└── README.md
```

## Categories Included

### Recipe Categories:
1. **Favorite Recipes** - User's liked recipes
2. **Most Popular Recipes** - Traditional favorites (25 recipes)
3. **Trending Recipes** - Modern fusion dishes (25 recipes)
4. **Chef Signature Recipes** - Special chef creations (25 recipes)
5. **Easy to Cook** - Simple recipes for beginners (25 recipes)
6. **Lunch Box Recipes** - Perfect for office/school (25 recipes)
7. **Healthy Recipes** - Nutritious millet-based dishes (25 recipes)
8. **Breakfast Recipes** - Traditional morning meals (25 recipes)
9. **Gym-Goers** - High protein recipes (25 recipes)
10. **Snacks Recipe** - Traditional Tamil snacks (25 recipes)
11. **Street Food** - Popular street food items (25 recipes)
12. **Baking** - Cakes, breads, and baked goods (25 recipes)
13. **International Cuisine** - Global dishes with Tamil twist (25 recipes)

### Product Categories:
1. **Groceries** - Grains, pulses, spices, vegetables, oils
2. **Kitchen Gadgets** - Cooking tools and equipment

### Class Categories:
1. **Cooking Classes** - Basic to advanced Tamil cooking
2. **Baking Classes** - Fundamental to artisan baking

## Key Features

- **Logo Integration**: Your logo appears on login, header, search, and all pages
- **Language Support**: Complete translation for English, Tamil, and Hindi
- **Recipe Details**: Ingredients, instructions, calories, cooking time, video tutorials
- **Interactive Features**: Favorites system, cart, wishlist
- **Responsive Design**: Works on desktop, tablet, and mobile
- **Clean Typography**: Black text on clean backgrounds for readability

## Login Credentials

For testing purposes, you can use any valid email format and any password to log in.

## Customization

- Update your logo URL in the components to replace the placeholder
- Modify the color scheme in App.css (currently uses #ff6b6b as primary color)
- Add real recipe data and images
- Integrate with a backend API for user management and data storage
- Add payment gateway integration for products and classes

## Technologies Used

- React.js 18
- React Router DOM
- CSS3 with Flexbox/Grid
- Local Storage for data persistence
- Responsive Design

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## License

This project is for educational/personal use. Please ensure you have proper licensing for any images or content used.
